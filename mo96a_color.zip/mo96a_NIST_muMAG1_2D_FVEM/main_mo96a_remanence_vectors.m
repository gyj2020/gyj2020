%MAIN_MO96A_REMANENCE_VECTORS Plot official mo96a remanent vector images.
root_dir = fileparts(mfilename('fullpath'));
addpath(root_dir);
main_reference_remanence_vectors
