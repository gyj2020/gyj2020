%MAIN_MO96A_HYSTERESIS Plot official loops and remanent vector images.
% This entry point writes visible, directly openable FIGs and no PNGs.
main_reference_hysteresis
