function main_reference_colored_remanence()
%MAIN_REFERENCE_COLORED_REMANENCE Generate only the coloured remanence FIGs.

root_dir = fileparts(mfilename('fullpath'));
addpath(genpath(root_dir));
code = current_submission_code();
output_dir = fullfile(root_dir,'results','reference','remanence');

remanence = load_nist_remanence_states(root_dir,code);
plot_nist_colored_remanence(remanence,output_dir);
save(fullfile(output_dir,[code '_remanence_reference_data.mat']), ...
    'remanence');

fprintf('\n%s coloured Vector Images at Remanence completed.\n',code);
fprintf('Openable colour FIG files are in:\n  %s\n',output_dir);
fprintf('No PNG file is generated.\n');
end
