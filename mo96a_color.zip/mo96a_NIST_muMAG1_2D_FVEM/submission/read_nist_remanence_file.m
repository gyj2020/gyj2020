function state = read_nist_remanence_file(filename,state_tag)
%READ_NIST_REMANENCE_FILE Read a NIST muMAG #1 remanent-state file.
%
% Standard files contain
%   x  y  z  m_x  m_y  m_z,
% but several early submissions omit z and contain
%   x  y  m_x  m_y  m_z.
% Positions are in micrometres and m is the reduced magnetization M/Ms.

if nargin < 2 || isempty(state_tag)
    [~,state_tag] = fileparts(filename);
end

fid = fopen(filename,'rt');
if fid < 0
    error('Cannot open NIST remanence file: %s',filename);
end
cleaner = onCleanup(@() fclose(fid)); %#ok<NASGU>

% Token extraction also tolerates the stray nonnumeric character present
% in one published mo96a data row, without changing any numeric value.
number_pattern = ...
    '[-+]?(?:(?:\d+(?:\.\d*)?)|(?:\.\d+))(?:[EeDd][-+]?\d+)?';
capacity = 1024;
values = zeros(capacity,6);
row_count = 0;
source_column_count = [];
line_number = 0;

while true
    line = fgetl(fid);
    if ~ischar(line)
        break;
    end
    line_number = line_number + 1;
    line = strtrim(line);
    if isempty(line) || line(1) == '#'
        continue;
    end

    tokens = regexp(line,number_pattern,'match');
    row = zeros(1,numel(tokens));
    for k = 1:numel(tokens)
        token = strrep(tokens{k},'D','E');
        token = strrep(token,'d','e');
        row(k) = str2double(token);
    end

    if numel(row) == 5
        % Early files use x,y,mx,my,mz.  The NIST specimen mid-plane is
        % z=0.010 micrometres; z does not affect the 2-D vector image.
        row = [row(1:2),0.010,row(3:5)];
        this_column_count = 5;
    elseif numel(row) >= 6
        row = row(1:6);
        this_column_count = 6;
    else
        error('Malformed numeric row %d in %s.',line_number,filename);
    end

    if isempty(source_column_count)
        source_column_count = this_column_count;
    elseif source_column_count ~= this_column_count
        error('Mixed five- and six-column rows in %s.',filename);
    end

    row_count = row_count + 1;
    if row_count > size(values,1)
        values = [values;zeros(size(values,1),6)]; %#ok<AGROW>
    end
    values(row_count,:) = row;
end

values = values(1:row_count,:);
if isempty(values)
    error('No remanent-state records were found in %s.',filename);
end
if any(~isfinite(values(:)))
    error('Non-finite remanent-state value in %s.',filename);
end

magnitude = sqrt(sum(values(:,4:6).^2,2));
state = struct();
state.tag = lower(state_tag);
state.filename = filename;
state.position_um = values(:,1:3);
state.m = values(:,4:6);
state.record_count = row_count;
state.source_column_count = source_column_count;
state.mean_reduced_m = mean(state.m,1);
state.magnitude = magnitude;
state.max_unit_length_error = max(abs(magnitude-1));
end
