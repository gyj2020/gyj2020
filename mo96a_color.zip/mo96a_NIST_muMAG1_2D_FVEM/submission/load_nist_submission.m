function reference = load_nist_submission(root_dir,submission_code)
%LOAD_NIST_SUBMISSION Load the two official NIST hysteresis data files.

submission_code = lower(strtrim(submission_code));
data_dir = fullfile(root_dir,'reference_data');
x_file = fullfile(data_dir,[submission_code 'hyx.dat']);
y_file = fullfile(data_dir,[submission_code 'hyy.dat']);
dsc_file = fullfile(data_dir,[submission_code 'dsc.txt']);

if ~exist(x_file,'file') || ~exist(y_file,'file')
    error('Reference data for %s are incomplete in %s.', ...
        submission_code,data_dir);
end

reference = struct();
reference.code = submission_code;
reference.x = read_nist_hysteresis_file(x_file,'x');
reference.y = read_nist_hysteresis_file(y_file,'y');
reference.description_file = dsc_file;
if exist(dsc_file,'file')
    reference.description_text = fileread(dsc_file);
else
    reference.description_text = '';
end
reference.source_report = ['https://www.ctcms.nist.gov/~rdm/std1/' ...
    submission_code(1:4) '/' submission_code '.html'];
reference.source_archive = ['https://www.ctcms.nist.gov/~rdm/std1/' ...
    submission_code(1:4) '/' submission_code '.tar.gz'];
end
