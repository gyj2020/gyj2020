function remanence = load_nist_remanence_states(root_dir,submission_code)
%LOAD_NIST_REMANENCE_STATES Load all bundled NIST remanent vector states.
%
% rx1/ry1 are the primary states reached while descending from positive
% saturation.  rx2/ry2, when supplied, are return-branch states reached
% while increasing the field from negative saturation.

submission_code = lower(strtrim(submission_code));
data_dir = fullfile(root_dir,'reference_data');
tags = {'rx1','ry1','rx2','ry2'};

remanence = struct();
remanence.code = submission_code;
remanence.available_tags = {};
remanence.source_guide = ...
    'https://www.ctcms.nist.gov/~rdm/sub_guide1.html';
remanence.source_comparison = ...
    'https://www.ctcms.nist.gov/~rdm/std1/vectorcompare.html';

for k = 1:numel(tags)
    tag = tags{k};
    filename = fullfile(data_dir,[submission_code tag '.dat']);
    if ~exist(filename,'file')
        continue;
    end

    state = read_nist_remanence_file(filename,tag);
    if tag(2) == 'x'
        state.applied_field_axis = 'short x-axis';
    else
        state.applied_field_axis = 'long y-axis';
    end
    if tag(3) == '1'
        state.field_history = 'descending from positive saturation';
    else
        state.field_history = 'ascending from negative saturation';
    end
    remanence.(tag) = state;
    remanence.available_tags{end+1} = tag; %#ok<AGROW>
end

if ~isfield(remanence,'rx1') || ~isfield(remanence,'ry1')
    error(['Primary NIST remanent states %srx1.dat and %sry1.dat ' ...
        'must both be present in %s.'],submission_code,submission_code,data_dir);
end
end
