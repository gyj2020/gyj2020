function output = plot_nist_remanence_vectors(remanence,output_dir)
%PLOT_NIST_REMANENCE_VECTORS Plot official NIST vector images at remanence.
%
% The NIST comparison page displays the 1-by-2 micrometre specimen after a
% 90 degree counterclockwise rotation.  This routine applies the same
% rigid rotation to both positions and in-plane magnetization vectors:
%       (x_plot,y_plot) = (2-y,x),  (u_plot,v_plot) = (-m_y,m_x).
% The primary output uses ry1 (long-axis saturation) and rx1 (short-axis
% saturation).  Optional return-branch rx2/ry2 states are also plotted when
% those files were supplied.  Only MATLAB FIG files are written.

if ~exist(output_dir,'dir')
    mkdir(output_dir);
end

code = lower(remanence.code);
output = struct();
output.files = {};

combined_file = fullfile(output_dir, ...
    [code '_Vector_Images_at_Remanence.fig']);
fig = figure('Color','w','Visible','on','Name', ...
    [code ' Vector Images at Remanence'],'NumberTitle','off', ...
    'Position',[100 80 1100 760]);
figure(fig);
ax1 = subplot(2,1,1);
draw_vector_state(ax1,remanence.ry1,code, ...
    'after saturation along the long y-axis (ry1)');
ax2 = subplot(2,1,2);
draw_vector_state(ax2,remanence.rx1,code, ...
    'after saturation along the short x-axis (rx1)');
save_openable_fig(fig,combined_file);
output.combined_figure = fig;
output.files{end+1} = combined_file;

primary_tags = {'ry1','rx1'};
for k = 1:numel(primary_tags)
    tag = primary_tags{k};
    if tag(2) == 'y'
        axis_name = 'long_axis';
        title_text = 'after saturation along the long y-axis';
    else
        axis_name = 'short_axis';
        title_text = 'after saturation along the short x-axis';
    end
    filename = fullfile(output_dir, ...
        [code '_remanence_' axis_name '_' tag '.fig']);
    single_fig = figure('Color','w','Visible','on','Name', ...
        [code ' ' tag ' remanent vector state'],'NumberTitle','off', ...
        'Position',[120 120 1100 560]);
    ax = axes('Parent',single_fig);
    draw_vector_state(ax,remanence.(tag),code, ...
        [title_text ' (' tag ')']);
    save_openable_fig(single_fig,filename);
    output.([tag '_figure']) = single_fig;
    output.files{end+1} = filename;
end

optional_tags = {'ry2','rx2'};
for k = 1:numel(optional_tags)
    tag = optional_tags{k};
    if ~isfield(remanence,tag)
        continue;
    end
    if tag(2) == 'y'
        axis_name = 'long_axis_return_branch';
        title_text = 'long-axis return-branch remanence';
    else
        axis_name = 'short_axis_return_branch';
        title_text = 'short-axis return-branch remanence';
    end
    filename = fullfile(output_dir, ...
        [code '_remanence_' axis_name '_' tag '.fig']);
    single_fig = figure('Color','w','Visible','on','Name', ...
        [code ' ' tag ' remanent vector state'],'NumberTitle','off', ...
        'Position',[140 140 1100 560]);
    ax = axes('Parent',single_fig);
    draw_vector_state(ax,remanence.(tag),code, ...
        [title_text ' (' tag ')']);
    save_openable_fig(single_fig,filename);
    output.([tag '_figure']) = single_fig;
    output.files{end+1} = filename;
end
end

function draw_vector_state(ax,state,code,state_description)
% Draw a decimated but spatially faithful in-plane arrow field.
index = select_vector_samples(state.position_um(:,1:2),2000);
x = state.position_um(index,1);
y = state.position_um(index,2);
mx = state.m(index,1);
my = state.m(index,2);

% Exact 90-degree counterclockwise rotation, followed by translation so
% that the displayed specimen occupies [0,2] x [0,1].
x_plot = 2-y;
y_plot = x;
u_plot = -my;
v_plot = mx;

% Use a fixed physical arrow length based on the displayed point density.
% quiver scale 0 disables MATLAB's automatic rescaling.
arrow_length = 0.72*sqrt(2/numel(index));
axes(ax); %#ok<LAXES>
quiver(x_plot,y_plot,arrow_length*u_plot,arrow_length*v_plot,0, ...
    'Color',[0.05 0.05 0.05],'LineWidth',0.65,'MaxHeadSize',0.85);
hold(ax,'on');
plot(ax,[0 2 2 0 0],[0 0 1 1 0],'k-','LineWidth',1.25);
hold(ax,'off');
axis(ax,'equal');
xlim(ax,[-0.03 2.03]);
ylim(ax,[-0.03 1.03]);
set(ax,'YDir','normal','Layer','top','Box','on','FontSize',10);
xlabel(ax,'rotated horizontal coordinate (original -y)  (\mum)');
ylabel(ax,'rotated vertical coordinate (original x)  (\mum)');
title(ax,{[code ': Vector Image at Remanence'], ...
    [state_description ', NIST display rotated CCW 90^\circ']}, ...
    'Interpreter','tex');
end

function index = select_vector_samples(position,max_arrows)
% Preserve all modest meshes; regularly stride dense rectangular meshes.
n = size(position,1);
if n <= max_arrows
    index = (1:n).';
    return;
end

x_values = unique(position(:,1));
y_values = unique(position(:,2));
if numel(x_values)*numel(y_values) == n
    stride = ceil(sqrt(n/max_arrows));
    x_keep = x_values(1:stride:end);
    y_keep = y_values(1:stride:end);
    keep = ismember(position(:,1),x_keep) & ...
        ismember(position(:,2),y_keep);
    index = find(keep);
else
    % NIST permits arbitrary point ordering and irregular cells.  Sort by
    % position before uniform selection so the choice is deterministic.
    [~,order] = sortrows(position,[2 1]);
    chosen = unique(round(linspace(1,n,max_arrows)));
    index = order(chosen);
end
end

function save_openable_fig(fig,filename)
set(fig,'Visible','on');
drawnow;
savefig(fig,filename);
end
