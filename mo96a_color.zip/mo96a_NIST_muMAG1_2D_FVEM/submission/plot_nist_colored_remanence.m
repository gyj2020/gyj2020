function output = plot_nist_colored_remanence(remanence,output_dir)
%PLOT_NIST_COLORED_REMANENCE Coloured angle map with vector overlay.
%
% The colour is the in-plane magnetization angle
%       theta = atan2(m_y,m_x) in [-pi,pi].
% Black arrows show (m_x,m_y).  The background is sampled on the common
% 100-by-200 grid described in the NIST muMAG #1 submission guide, using
% nearest-neighbour values from the official rx/ry data.  Coordinates are
% kept in the original portrait orientation: 0<=x<=1 and 0<=y<=2 microns.
% Only directly openable MATLAB FIG files are written; no PNG is produced.

if ~exist(output_dir,'dir')
    mkdir(output_dir);
end

code = lower(remanence.code);
output = struct();
output.files = {};

combined_file = fullfile(output_dir, ...
    [code '_Colored_Vector_Images_at_Remanence.fig']);
combined_fig = figure('Color','w','Visible','on','Name', ...
    [code ' coloured Vector Images at Remanence'], ...
    'NumberTitle','off','Position',[80 40 1180 760]);
figure(combined_fig);
ax1 = subplot(1,2,1);
draw_coloured_state(ax1,remanence.rx1,code, ...
    'short_x, descending_remanence');
ax2 = subplot(1,2,2);
draw_coloured_state(ax2,remanence.ry1,code, ...
    'long_y, descending_remanence');
save_openable_fig(combined_fig,combined_file);
output.combined_figure = combined_fig;
output.files{end+1} = combined_file;

tags = {'rx1','ry1','rx2','ry2'};
for k = 1:numel(tags)
    tag = tags{k};
    if ~isfield(remanence,tag)
        continue;
    end
    [plot_label,file_label] = state_labels(tag);
    filename = fullfile(output_dir, ...
        [code '_colored_' file_label '.fig']);
    fig = figure('Color','w','Visible','on','Name', ...
        [code ' ' plot_label],'NumberTitle','off', ...
        'Position',[120 60 720 900]);
    ax = axes('Parent',fig);
    draw_coloured_state(ax,remanence.(tag),code,plot_label);
    save_openable_fig(fig,filename);
    output.([tag '_figure']) = fig;
    output.files{end+1} = filename;
end
end

function draw_coloured_state(ax,state,code,plot_label)
[x_grid,y_grid,theta] = remanence_angle_grid(state);
index = select_vector_samples(state.position_um(:,1:2),2000);
x = state.position_um(index,1);
y = state.position_um(index,2);
mx = state.m(index,1);
my = state.m(index,2);

axes(ax); %#ok<LAXES>
imagesc(x_grid,y_grid,theta);
set(ax,'YDir','normal');
caxis(ax,[-pi pi]);
colormap(ax,hsv(256));
cb = colorbar(ax);
try
    set(cb,'Ticks',-3:1:3);
catch
    set(cb,'YTick',-3:1:3);
end

hold(ax,'on');
arrow_length = 0.72*sqrt(2/numel(index));
quiver(ax,x,y,arrow_length*mx,arrow_length*my,0, ...
    'Color','k','LineWidth',0.70,'MaxHeadSize',0.85);
plot(ax,[0 1 1 0 0],[0 0 2 2 0],'k-','LineWidth',1.15);
hold(ax,'off');

axis(ax,'image');
xlim(ax,[0 1]);
ylim(ax,[0 2]);
set(ax,'Layer','top','Box','on','FontSize',12,'LineWidth',1.0);
xlabel(ax,'x (\mum)','Interpreter','tex','FontSize',14);
ylabel(ax,'y (\mum)','Interpreter','tex','FontSize',14);
title(ax,[code ', ' plot_label],'Interpreter','none','FontSize',14);
end

function [x_grid,y_grid,theta] = remanence_angle_grid(state)
% Reproduce the NIST one-point-fit idea on a common 100-by-200 grid.
x_grid = linspace(0.005,0.995,100);
y_grid = linspace(0.005,1.995,200);
[X,Y] = meshgrid(x_grid,y_grid);
x = state.position_um(:,1);
y = state.position_um(:,2);
mx = state.m(:,1);
my = state.m(:,2);

MX = griddata(x,y,mx,X,Y,'nearest');
MY = griddata(x,y,my,X,Y,'nearest');
if any(~isfinite(MX(:))) || any(~isfinite(MY(:)))
    error('Nearest-neighbour remanence interpolation produced non-finite values.');
end
theta = atan2(MY,MX);
end

function index = select_vector_samples(position,max_arrows)
n = size(position,1);
if n <= max_arrows
    index = (1:n).';
    return;
end

x_values = unique(position(:,1));
y_values = unique(position(:,2));
if numel(x_values)*numel(y_values) == n
    stride = ceil(sqrt(n/max_arrows));
    x_keep = x_values(1:stride:end);
    y_keep = y_values(1:stride:end);
    keep = ismember(position(:,1),x_keep) & ...
        ismember(position(:,2),y_keep);
    index = find(keep);
else
    [~,order] = sortrows(position,[2 1]);
    chosen = unique(round(linspace(1,n,max_arrows)));
    index = order(chosen);
end
end

function [plot_label,file_label] = state_labels(tag)
if tag(2) == 'x'
    axis_label = 'short_x';
else
    axis_label = 'long_y';
end
if tag(3) == '1'
    branch_label = 'descending_remanence';
else
    branch_label = 'ascending_remanence';
end
plot_label = [axis_label ', ' branch_label];
file_label = [axis_label '_' branch_label];
end

function save_openable_fig(fig,filename)
set(fig,'Visible','on');
drawnow;
savefig(fig,filename);
end
