function param = submission_parameters(submission_code,preset)
%SUBMISSION_PARAMETERS Report-informed settings for a NIST submission.
%
% These settings make the common 2-D FVEM code comparable with the named
% historical report.  They do not reconstruct the submitter's unpublished
% implementation.  Official curves are supplied separately in
% reference_data and are plotted by main_reference_hysteresis.m.

if nargin < 2 || isempty(preset)
    preset = 'reported';
end
submission_code = lower(strtrim(submission_code));

if strcmpi(preset,'quick')
    param = default_mumag1_parameters('quick');
else
    param = default_mumag1_parameters('normal');
end

param.submission_code = submission_code;
param.initial_state = 'uniform';
param.random_seed = 9701;
param.planar_magnetization = true;
param.use_reference_field_schedule = ~strcmpi(preset,'quick');
param.simulation_demag_method = ...
    'zero-padded FFT thickness-averaged thin-film tensor';
param.reproduction_scope = ['report-informed 2-D FVEM comparison; ' ...
    'not the historical submitter code'];

switch submission_code
    case 'du96a'
        param.nx = 20;
        param.ny = 40;
        param.reported_cell_nm = [62.0 53.7 20.0];
        param.reported_total_cells = 814;
        param.reported_field_states = 396;
        param.reported_magnetization_dimension = 2;
        param.reported_grid_dimension = 2;
        param.reported_initial_state = 'uniform positive saturation';
        param.reported_demag_method = 'direct calculation';
        param.reported_solver = 'not specified';
        param.mesh_qualification = ['Historical mesh: 814 hexagonal cells. ' ...
            'Rerun mesh: 20-by-40 rectangles split into triangles.'];
    case 'fr96a'
        param.nx = 20;
        param.ny = 40;
        param.reported_cell_nm = [50.0 50.0 20.0];
        param.reported_total_cells = 800;
        param.reported_field_states = 396;
        param.reported_magnetization_dimension = 2;
        param.reported_grid_dimension = 2;
        param.reported_initial_state = 'uniform positive saturation';
        param.reported_demag_method = 'direct calculation';
        param.reported_solver = 'not specified';
        param.mesh_qualification = ['Historical mesh: 800 square cells. ' ...
            'Rerun mesh has the same 20-by-40 nominal cell layout.'];
    case 'lu96a'
        param.nx = 30;
        param.ny = 60;
        param.reported_cell_nm = [33.0 33.0 20.0];
        param.reported_total_cells = 1800;
        param.reported_field_states = 123;
        param.reported_magnetization_dimension = 3;
        param.reported_grid_dimension = 2;
        param.planar_magnetization = false;
        param.reported_initial_state = 'uniform';
        param.reported_demag_method = ...
            'truncation of magnetostatic interaction range';
        param.reported_solver = 'not specified';
        param.mesh_qualification = ['Historical mesh: 30-by-60 nominal ' ...
            'cells with three-component magnetization.'];
    case 'mo96a'
        param.nx = 50;
        param.ny = 100;
        param.reported_cell_nm = [20.0 20.0 20.0];
        param.reported_total_cells = 5000;
        param.reported_field_states = 133;
        param.reported_magnetization_dimension = 3;
        param.reported_grid_dimension = 2;
        param.planar_magnetization = false;
        param.reported_initial_state = 'uniform';
        param.reported_demag_method = 'FFT';
        param.reported_solver = 'not specified';
        param.mesh_qualification = ['Historical and rerun nominal cell ' ...
            'layout: 50-by-100, 20 nm in-plane spacing.'];
    case 'pb97a'
        param.nx = 50;
        param.ny = 100;
        param.reported_cell_nm = [20.0 20.0 20.0];
        param.reported_total_cells = 5000;
        param.reported_field_states = 100;
        param.reference_file_records = 200;
        param.reported_magnetization_dimension = 2;
        param.reported_grid_dimension = 2;
        param.initial_state = 'random';
        param.reported_initial_state = 'random';
        param.reported_demag_method = 'FFT';
        param.reported_solver = 'energy minimization / conjugate gradient';
        param.tol_torque = 1.0e-4;
        param.max_relax_iter = 2500;
        param.mesh_qualification = ['Historical and rerun nominal cell ' ...
            'layout: 50-by-100, 20 nm in-plane spacing.'];
    otherwise
        error('Unsupported NIST submission code: %s',submission_code);
end

if strcmpi(preset,'quick')
    % Preserve the historical metadata while forcing a very small test.
    param.nx = 12;
    param.ny = 24;
    param.dH_mT = 25.0;
    param.max_relax_iter = 120;
    param.min_relax_iter = 5;
    param.tol_torque = 2.0e-3;
    param.tol_change = 2.0e-3;
    param.demag_pad_factor = 2;
end
param.preset = lower(preset);
end
