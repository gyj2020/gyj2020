function Hout = ensure_zero_field_samples(Hin)
%ENSURE_ZERO_FIELD_SAMPLES Insert H=0 at every unsampled sign crossing.
%
% Some early NIST files use an even number of field records and straddle
% zero.  The FVEM rerun inserts the required remanent states without
% changing any of the reported nonzero field values.

Hin = Hin(:).';
if isempty(Hin) || any(~isfinite(Hin))
    error('The field schedule must be a nonempty finite vector.');
end

Hout = zeros(1,2*numel(Hin));
j = 0;
for k = 1:(numel(Hin)-1)
    j = j+1;
    Hout(j) = Hin(k);
    if Hin(k)*Hin(k+1) < 0
        j = j+1;
        Hout(j) = 0;
    end
end
j = j+1;
Hout(j) = Hin(end);
Hout = Hout(1:j);
end
