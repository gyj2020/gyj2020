function data = read_nist_hysteresis_file(filename,axis_name)
%READ_NIST_HYSTERESIS_FILE Read historical muMAG problem-1 loop data.
%
% The early submissions are not completely uniform: some files contain
% six numeric columns (H_z omitted), whereas later files contain the seven
% columns requested by NIST.  This reader accepts both layouts and converts
% the applied field to mu_0 H in mT.

if nargin < 2 || isempty(axis_name)
    if ~isempty(strfind(lower(filename),'hyx')) %#ok<STREMP>
        axis_name = 'x';
    elseif ~isempty(strfind(lower(filename),'hyy')) %#ok<STREMP>
        axis_name = 'y';
    else
        error('axis_name must be supplied when the filename lacks hyx/hyy.');
    end
end

fid = fopen(filename,'r');
if fid < 0
    error('Cannot open NIST data file: %s',filename);
end
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>

units = '';
rows = zeros(0,7);
line_number = 0;
while true
    line = fgetl(fid);
    if ~ischar(line)
        break;
    end
    line_number = line_number+1;
    trimmed = strtrim(line);
    if isempty(trimmed)
        continue;
    end
    if trimmed(1) == '#'
        token = regexp(trimmed,'(?i)units\s*:\s*([^\s#]+)', ...
            'tokens','once');
        if ~isempty(token)
            units = token{1};
        end
        continue;
    end

    values = sscanf(trimmed,'%f').';
    if numel(values) == 6
        % step, Hx, Hy, mx, my, mz -> insert Hz=0.
        rows(end+1,:) = [values(1:3),0,values(4:6)]; %#ok<AGROW>
    elseif numel(values) >= 7
        rows(end+1,:) = values(1:7); %#ok<AGROW>
    else
        warning('Ignoring malformed numeric line %d in %s.', ...
            line_number,filename);
    end
end

if isempty(rows)
    error('No hysteresis records were read from %s.',filename);
end
if isempty(units)
    error('The required "# Units:" line is missing in %s.',filename);
end

factor_to_mT = field_factor_to_mT(units);
H_mT = factor_to_mT*rows(:,2:4);
m = rows(:,5:7);

switch lower(axis_name)
    case 'x'
        nominal_component = 1;
    case 'y'
        nominal_component = 2;
    otherwise
        error('axis_name must be ''x'' or ''y''.');
end

% Recover the positive applied-field direction from the record itself.
[~,positive_index] = max(H_mT(:,nominal_component));
eH = H_mT(positive_index,:).';
if norm(eH) == 0
    error('Cannot infer the applied-field direction from %s.',filename);
end
eH = eH/norm(eH);
if eH(nominal_component) < 0
    eH = -eH;
end

data = struct();
data.filename = filename;
data.axis_name = lower(axis_name);
data.units_original = units;
data.step = rows(:,1).';
data.Hvector_original = rows(:,2:4).';
data.Hvector_mT = H_mT.';
data.mavg = m.';
data.field_direction = eH;
data.Hparallel_mT = (H_mT*eH).';
data.m_parallel = (m*eH).';
data.record_count = size(rows,1);
end

function factor = field_factor_to_mT(units)
key = lower(strrep(strtrim(units),' ',''));
mu0 = 4*pi*1.0e-7;
switch key
    case 't'
        factor = 1.0e3;
    case 'mt'
        factor = 1.0;
    case 'g'
        factor = 0.1;
    case 'kg'
        factor = 100.0;
    case 'oe'
        factor = 0.1;
    case 'koe'
        factor = 100.0;
    case 'a/m'
        factor = mu0*1.0e3;
    case 'ka/m'
        factor = mu0*1.0e6;
    otherwise
        error('Unsupported NIST applied-field unit: %s',units);
end
end
