function fig = plot_simulation_vs_reference(result_x,result_y,reference,param)
%PLOT_SIMULATION_VS_REFERENCE Overlay FVEM output and official NIST data.

out = param.output_dir;
if ~exist(out,'dir')
    mkdir(out);
end
code = lower(reference.code);
hlimit = max([50,max(abs(reference.x.Hparallel_mT)), ...
    max(abs(reference.y.Hparallel_mT)), ...
    max(abs(result_x.Hscalar_mT)),max(abs(result_y.Hscalar_mT))]);

fig = figure('Color','w','Visible','on','Name', ...
    [code ' simulation versus reference'],'NumberTitle','off');

subplot(1,2,1);
plot(reference.x.Hparallel_mT,reference.x.m_parallel,'-', ...
    'LineWidth',1.45); hold on;
plot(result_x.Hscalar_mT,result_x.m_parallel,'--', ...
    'LineWidth',1.25);
plot([-hlimit hlimit],[0 0],':','Color',[0.45 0.45 0.45]);
xlabel('\mu_0H_{\parallel} (mT)'); ylabel('M_{\parallel}/M_s');
title('Short-axis field');
legend('official NIST data','2-D FVEM rerun','Location','best');
xlim([-hlimit hlimit]); ylim([-1.1 1.1]); grid on; box on;

subplot(1,2,2);
plot(reference.y.Hparallel_mT,reference.y.m_parallel,'-', ...
    'LineWidth',1.45); hold on;
plot(result_y.Hscalar_mT,result_y.m_parallel,'--', ...
    'LineWidth',1.25);
plot([-hlimit hlimit],[0 0],':','Color',[0.45 0.45 0.45]);
xlabel('\mu_0H_{\parallel} (mT)'); ylabel('M_{\parallel}/M_s');
title('Long-axis field');
legend('official NIST data','2-D FVEM rerun','Location','best');
xlim([-hlimit hlimit]); ylim([-1.1 1.1]); grid on; box on;

set(fig,'Visible','on');
drawnow;
savefig(fig,fullfile(out,[code '_simulation_vs_reference.fig']));
end
