function figures = plot_nist_reference_loops(reference,output_dir)
%PLOT_NIST_REFERENCE_LOOPS Plot official NIST data and save openable FIGs.
%
% All curves are produced with MATLAB's plot command.  No raster image is
% written.  Figures remain visible and are saved with Visible='on' so that
% double-clicking the FIG file displays the graphics immediately.

if ~exist(output_dir,'dir')
    mkdir(output_dir);
end
code = lower(reference.code);
hlimit = max([50,max(abs(reference.x.Hparallel_mT)), ...
    max(abs(reference.y.Hparallel_mT))]);

figures = cell(1,3);
figures{1} = figure('Color','w','Visible','on','Name', ...
    [code ' official NIST hysteresis loops'],'NumberTitle','off');
plot(reference.x.Hparallel_mT,reference.x.m_parallel,'-', ...
    'LineWidth',1.35); hold on;
plot(reference.y.Hparallel_mT,reference.y.m_parallel,'-', ...
    'LineWidth',1.35);
plot([-hlimit hlimit],[0 0],':','Color',[0.45 0.45 0.45]);
plot([0 0],[-1.1 1.1],':','Color',[0.45 0.45 0.45]);
xlabel('\mu_0H_{\parallel} (mT)');
ylabel('M_{\parallel}/M_s');
legend('short-axis field','long-axis field','Location','best');
title([code ': official NIST \muMAG problem 1 loops']);
xlim([-hlimit hlimit]); ylim([-1.1 1.1]); grid on; box on;
save_openable_fig(figures{1},fullfile(output_dir, ...
    [code '_reference_hysteresis_both_axes.fig']));

figures{2} = plot_components(reference.x,code,'short x-axis', ...
    fullfile(output_dir,[code '_reference_short_axis_components.fig']));
figures{3} = plot_components(reference.y,code,'long y-axis', ...
    fullfile(output_dir,[code '_reference_long_axis_components.fig']));
end

function fig = plot_components(data,code,axis_label,filename)
hlimit = max(50,max(abs(data.Hparallel_mT)));
fig = figure('Color','w','Visible','on','Name', ...
    [code ' ' axis_label ' components'],'NumberTitle','off');
plot(data.Hparallel_mT,data.mavg(1,:),'-','LineWidth',1.20); hold on;
plot(data.Hparallel_mT,data.mavg(2,:),'--','LineWidth',1.20);
plot(data.Hparallel_mT,data.mavg(3,:),':','LineWidth',1.20);
plot([-hlimit hlimit],[0 0],':','Color',[0.45 0.45 0.45]);
xlabel('\mu_0H_{\parallel} (mT)');
ylabel('M_i/M_s');
legend('m_x','m_y','m_z','Location','best');
title([code ': official data, field near ' axis_label]);
xlim([-hlimit hlimit]); ylim([-1.1 1.1]); grid on; box on;
save_openable_fig(fig,filename);
end

function save_openable_fig(fig,filename)
set(fig,'Visible','on');
drawnow;
savefig(fig,filename);
end
