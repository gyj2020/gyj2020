# 二维 Landau--Lifshitz 方程齐次 Neumann 边界 FVEM 程序

本程序包实现单位正方形上的顶点中心有限体积元方法（vertex-centred FVEM），用于二维 Landau--Lifshitz 方程的时间与空间精度测试。

当前版本还加入了 NIST μMAG 标准问题 1 的二维厚度平均磁滞回线模拟。磁滞部分的模型、运行方式、输出文件和适用范围见 `README_HYSTERESIS_CN.md`。

## 1. 数值问题

求解

\[
\boldsymbol m_t+\boldsymbol m\times\Delta\boldsymbol m
+\alpha\boldsymbol m\times(\boldsymbol m\times\Delta\boldsymbol m)
=\boldsymbol f
\]

并采用齐次 Neumann 边界条件

\[
\partial_n\boldsymbol m=0\qquad\text{on }\partial\Omega,
\quad \Omega=[0,1]^2.
\]

制造解为

\[
\boldsymbol m=(\cos(\phi)\sin t,\;\sin(\phi)\sin t,\;\cos t)^T,
\quad
\phi=x^2(1-x)^2y^2(1-y)^2.
\]

默认参数为 `alpha=0.01`、`T=5.0e-3`。

## 2. 这里使用的确实是 FVEM

- 原网格为 P1 三角形网格；
- 每个顶点周围建立“边中点—三角形重心”型对偶控制体；
- 扩散离散矩阵由对偶控制体内部边界上的数值通量
  `-int grad(phi_j).n ds` 直接组装；
- 变系数交叉项由 `int w_h grad(phi_j).n ds` 组装；
- 物理边界上的通量不进入矩阵，因为齐次 Neumann 通量为零；
- 边界顶点始终保留为未知量，不做 Dirichlet 行替换。

对于常系数、P1 元和当前重心型对偶网格，FVEM 通量矩阵在代数上与 P1 刚度矩阵相同；程序仍然是从控制体通量构造该矩阵，而不是用 Galerkin 体积分代替。

## 3. 四项输出

两个主程序均输出：

1. `Linf`：节点处向量误差的最大欧氏范数；
2. `L2`：连续 P1 数值解的向量 L2 误差；
3. `H1`：包含 L2 部分的完整向量 H1 误差；
4. `Length`：单位长度约束误差 `||1-|m_h^n|^2||_{L2}`。

第四项不是 H1 半范。它通过三角形五次精确积分公式直接积分，针对 P1 数值解时能精确积分该四次多项式。

## 4. 运行方法

将整个文件夹解压后，在 MATLAB 中进入根目录。

先执行快速完整性检查：

```matlab
check_package
run_quick_test
```

时间收敛测试：

```matlab
main_dt
```

默认固定 `dx=dy=1/100`，测试 `dt=T/40,T/60,T/100,T/160`，前三项与同一空间网格上的 `dt_ref=T/2560` 参考解比较；第四项直接取每个数值解自身的单位长度约束误差。

空间收敛测试：

```matlab
main_dx
```

二维磁滞回线：

```matlab
run_hysteresis_quick_test   % 粗网格完整性测试
main_hysteresis_2D          % 正式计算短轴和长轴回线
```

随包附带的 NIST 历史提交数据可直接绘图，无需重新进行耗时松弛：

```matlab
main_reference_hysteresis          % 官方回线，并自动生成剩磁矢量图
main_reference_remanence_vectors   % 只生成 Vector Images at Remanence
main_reference_colored_remanence   % 只生成彩色角度背景与黑色箭头图
```

官方剩磁矢量图保存在 `results/reference/remanence/`，由 `quiver` 和
`plot` 绘制；彩色版本再用 `imagesc` 显示 `atan2(m_y,m_x)`。全部结果直接
保存为可双击打开的 MATLAB `.fig`，不生成 PNG。

默认固定 `dt=1.0e-7`，测试 `h=1/8,1/16,1/24,1/32`。这一设置需要 50000 个时间步，运行时间会明显长于快速测试。

结果 `.mat`、`.fig` 和 `.txt` 文件保存在 `results` 文件夹中。图像采用 MATLAB 原生 FIG 格式保存，不生成 PNG 文件。

## 5. 子包结构

```text
mesh/         原网格、P1 几何量、对偶控制体通量系数和积分规则
assembly/     FVEM 质量矩阵、扩散矩阵、交叉项和右端项组装
solver/       线性化后向 Euler FVEM 时间推进及预条件器
exact/        精确解、梯度、制造源项和初值
error/        Linf、L2、H1、单位长度误差及数值解差
postprocess/  收敛阶、结果表格和 log-log 图
tests/        FVEM 通量恒等式与制造解/Neumann 条件检查
hysteresis/   μMAG #1 参数、退磁场、松弛求解与 NIST 格式输出
```

程序不依赖第三方 MATLAB 工具箱；使用 MATLAB 自带的稀疏矩阵、`gmres`、`chol`/`ilu` 和绘图函数即可。
