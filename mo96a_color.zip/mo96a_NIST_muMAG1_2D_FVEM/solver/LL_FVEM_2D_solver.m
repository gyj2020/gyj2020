function [Linf,L2,H1,Llen,m,info] = ...
    LL_FVEM_2D_solver(data,Tend,nt,alpha,options)
%LL_FVEM_2D_SOLVER Linearized backward-Euler vertex-centred FVEM.
%
% Equation:
%   m_t + m x Delta(m) + alpha*m x (m x Delta(m)) = f.
%
% For |m|=1 it is written as
%   m_t - alpha*Delta(m) + m x Delta(m)
%       = alpha*|grad(m)|^2*m + f.
%
% At step n+1 the coefficient in the cross term and the nonlinear right
% side are evaluated at m^n.  The new Laplacian is implicit.  No nodal
% renormalization is performed, so the reported length defect is genuine.
%
% Homogeneous Neumann data enter naturally: external physical-boundary
% fluxes are zero and no boundary row is replaced.

if nargin < 5
    options = struct();
end
if nt < 1 || nt ~= round(nt)
    error('nt must be a positive integer.');
end
if Tend <= 0 || alpha < 0
    error('Tend must be positive and alpha must be nonnegative.');
end

linear_solver = option_value(options,'linear_solver','gmres');
gmres_restart = option_value(options,'gmres_restart',30);
gmres_tolerance = option_value(options,'gmres_tolerance',1.0e-10);
gmres_maxit = option_value(options,'gmres_maxit',15);
direct_fallback = option_value(options,'direct_fallback',true);
verbose = option_value(options,'verbose',false);

N = data.N;
dt = Tend/nt;
Z = sparse(N,N);
M = assemble_matrix_M_FVEM_2D(data);
K = assemble_matrix_FVEM_2D(data);
S = M/dt+alpha*K;

if strcmpi(linear_solver,'gmres')
    preconditioner = make_LL_preconditioner(S,K,N);
else
    preconditioner = [];
end

m = initialize_m0(data.P);
old = [m(1,:)';m(2,:)';m(3,:)'];

nonzero_flags = 0;
fallback_count = 0;
max_relative_residual = 0;
max_krylov_steps = 0;
timer_id = tic;

for n = 0:nt-1
    tnew = (n+1)*dt;

    Q1 = assemble_matrix_FVEM_xielv_2D(data,m(1,:));
    Q2 = assemble_matrix_FVEM_xielv_2D(data,m(2,:));
    Q3 = assemble_matrix_FVEM_xielv_2D(data,m(3,:));

    % Block representation of m^n x Delta(m^{n+1}).
    A = [ S   -Q3   Q2; ...
          Q3   S   -Q1; ...
         -Q2   Q1    S ];

    rhs_time = [M*old(1:N);M*old(N+1:2*N);M*old(2*N+1:3*N)]/dt;
    rhs = rhs_time ...
        + assemble_vector_nonlinear_FVEM_2D(data,m,alpha) ...
        + assemble_vector_FVEM_2D(data,tnew,alpha);

    if strcmpi(linear_solver,'backslash') || strcmpi(linear_solver,'direct')
        X = A\rhs;
        flag = 0;
        relres = norm(A*X-rhs)/max(norm(rhs),eps);
        krylov_steps = 0;
    elseif strcmpi(linear_solver,'gmres')
        [X,flag,relres,iter] = gmres(A,rhs,gmres_restart, ...
            gmres_tolerance,gmres_maxit,preconditioner,[],old);
        if numel(iter) == 2
            krylov_steps = max(0,(iter(1)-1)*gmres_restart+iter(2));
        else
            krylov_steps = iter;
        end

        if flag ~= 0
            nonzero_flags = nonzero_flags+1;
            if direct_fallback
                X = A\rhs;
                fallback_count = fallback_count+1;
                relres = norm(A*X-rhs)/max(norm(rhs),eps);
            elseif verbose
                warning('GMRES flag=%d at time step %d (relative residual %.3e).', ...
                    flag,n+1,relres);
            end
        end
    else
        error('Unknown linear_solver: %s',linear_solver);
    end

    max_relative_residual = max(max_relative_residual,relres);
    max_krylov_steps = max(max_krylov_steps,krylov_steps);
    old = X;
    m = [X(1:N)';X(N+1:2*N)';X(2*N+1:3*N)'];

    if verbose && (n == 0 || n+1 == nt || mod(n+1,max(1,ceil(nt/10))) == 0)
        fprintf('  step %d/%d, t=%.8e, relres=%.3e\n',n+1,nt,tnew,relres);
    end
end

elapsed_seconds = toc(timer_id);
Linf = get_maximum_error(data,m,Tend);
L2 = get_L2_error(data,m,Tend);
H1 = get_H1_error(data,m,Tend);
Llen = get_length_error(data,m);

info = struct('nt',nt,'dt',dt,'elapsed_seconds',elapsed_seconds, ...
    'linear_solver',linear_solver,'gmres_nonzero_flags',nonzero_flags, ...
    'direct_fallback_count',fallback_count, ...
    'max_relative_residual',max_relative_residual, ...
    'max_krylov_steps',max_krylov_steps);
end

function value = option_value(options,name,default_value)
if isstruct(options) && isfield(options,name)
    value = options.(name);
else
    value = default_value;
end
end
