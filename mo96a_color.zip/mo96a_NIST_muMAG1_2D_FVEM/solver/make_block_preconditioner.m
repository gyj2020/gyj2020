function applyM = make_block_preconditioner(S,N)
%MAKE_BLOCK_PRECONDITIONER Block-diagonal solver for three LL components.
%   The same positive definite scalar block S is used for every component.

solve_one = [];

% MATLAB route (decomposition caches the factorization).
if exist('decomposition','file') == 2 || exist('decomposition','builtin') == 5
    try
        DS = decomposition(S,'chol');
        solve_one = @(b) DS\b;
    catch
        try
            DS = decomposition(S,'lu');
            solve_one = @(b) DS\b;
        catch
            solve_one = [];
        end
    end
end

% MATLAB/Octave-compatible sparse Cholesky route.
if isempty(solve_one)
    try
        [L,p] = chol(S,'lower');
        if p == 0
            solve_one = @(b) L'\(L\b);
        end
    catch
        solve_one = [];
    end
end

% Last sparse-factor fallback.
if isempty(solve_one)
    try
        setup.type = 'ilutp';
        setup.droptol = 1.0e-4;
        [L,U] = ilu(S,setup);
        solve_one = @(b) U\(L\b);
    catch
        d = full(diag(S));
        d(abs(d) < eps) = 1;
        solve_one = @(b) b./d;
    end
end

applyM = @(x) [solve_one(x(1:N)); ...
               solve_one(x(N+1:2*N)); ...
               solve_one(x(2*N+1:3*N))];
end

