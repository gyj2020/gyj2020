function applyM = make_LL_preconditioner(S,K,N)
%MAKE_LL_PRECONDITIONER Fixed preconditioner based on m=(0,0,1).
%
% At the initial state Q_3=-K and Q_1=Q_2=0.  The first two real blocks
% [S K;-K S] are equivalent to the single complex matrix S-i*K.  Factoring
% that N-by-N matrix is cheaper than factoring the full 3N-by-3N block.

solve_complex = [];
solve_scalar = [];

if exist('decomposition','file') == 2 || exist('decomposition','builtin') == 5
    try
        DC = decomposition(S-1i*K,'lu');
        DS = decomposition(S,'chol');
        solve_complex = @(b) DC\b;
        solve_scalar = @(b) DS\b;
    catch
        solve_complex = [];
        solve_scalar = [];
    end
end

if isempty(solve_complex)
    try
        C = S-1i*K;
        [LC,UC,PC,QC] = lu(C);
        solve_complex = @(b) QC*(UC\(LC\(PC*b)));
        [LS,p] = chol(S,'lower');
        if p ~= 0
            error('Scalar block is not positive definite.');
        end
        solve_scalar = @(b) LS'\(LS\b);
    catch
        applyM = make_block_preconditioner(S,N);
        return;
    end
end

applyM = @(x) apply_LL_blocks(x,solve_complex,solve_scalar,N);
end

function y = apply_LL_blocks(x,solve_complex,solve_scalar,N)
z = solve_complex(x(1:N)+1i*x(N+1:2*N));
y = [real(z);imag(z);solve_scalar(x(2*N+1:3*N))];
end

