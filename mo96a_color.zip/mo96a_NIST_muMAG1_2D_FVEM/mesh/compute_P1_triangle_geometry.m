function [area,gx,gy] = compute_P1_triangle_geometry(P,T)
%COMPUTE_P1_TRIANGLE_GEOMETRY Areas and gradients of local P1 functions.
%   gx(i,e), gy(i,e) are the two derivatives of local basis function i on
%   triangle e.  All triangles must be counter-clockwise.

X1 = P(:,T(1,:));
X2 = P(:,T(2,:));
X3 = P(:,T(3,:));

detJ = (X2(1,:)-X1(1,:)).*(X3(2,:)-X1(2,:)) ...
     - (X3(1,:)-X1(1,:)).*(X2(2,:)-X1(2,:));
area = 0.5*detJ;
if any(area <= 0)
    error('Every triangle must have positive counter-clockwise area.');
end

gx = zeros(3,size(T,2));
gy = zeros(3,size(T,2));
gx(1,:) = (X2(2,:)-X3(2,:))./(2*area);
gy(1,:) = (X3(1,:)-X2(1,:))./(2*area);
gx(2,:) = (X3(2,:)-X1(2,:))./(2*area);
gy(2,:) = (X1(1,:)-X3(1,:))./(2*area);
gx(3,:) = (X1(2,:)-X2(2,:))./(2*area);
gy(3,:) = (X2(1,:)-X1(1,:))./(2*area);
end

