function [P,T] = generate_uniform_triangular_mesh_2D(nx,ny,domain)
%GENERATE_UNIFORM_TRIANGULAR_MESH_2D Uniform CCW triangular primal mesh.
%   P is 2-by-N and T is 3-by-E.  Nodes are numbered column by column,
%   consistently with the original 2DLLGFVEM program.

if nargin < 3
    domain = [0 1 0 1];
end
if numel(domain) ~= 4
    error('domain must be [left right bottom top].');
end
if nx < 1 || ny < 1 || nx ~= round(nx) || ny ~= round(ny)
    error('nx and ny must be positive integers.');
end

left = domain(1); right = domain(2);
bottom = domain(3); top = domain(4);
if right <= left || top <= bottom
    error('The domain bounds are invalid.');
end

xs = linspace(left,right,nx+1);
ys = linspace(bottom,top,ny+1);
N = (nx+1)*(ny+1);
P = zeros(2,N);
node = @(i,j) i*(ny+1)+j+1;

for i = 0:nx
    for j = 0:ny
        P(:,node(i,j)) = [xs(i+1);ys(j+1)];
    end
end

T = zeros(3,2*nx*ny);
e = 0;
for i = 0:nx-1
    for j = 0:ny-1
        n00 = node(i,j);
        n10 = node(i+1,j);
        n01 = node(i,j+1);
        n11 = node(i+1,j+1);

        e = e+1;
        T(:,e) = [n00;n10;n01];
        e = e+1;
        T(:,e) = [n01;n10;n11];
    end
end
end

