function [lambda,w] = triangle_quadrature_rule()
%TRIANGLE_QUADRATURE_RULE Seven-point degree-five Dunavant rule.
%   lambda is 3-by-7 in barycentric coordinates.  The weights sum to one,
%   so a physical-triangle integral is area*sum(w(q)*f(x_q)).

a1 = 0.059715871789770;
b1 = 0.470142064105115;
a2 = 0.797426985353087;
b2 = 0.101286507323456;

lambda = [ ...
    1/3, a1, b1, b1, a2, b2, b2; ...
    1/3, b1, a1, b1, b2, a2, b2; ...
    1/3, b1, b1, a1, b2, b2, a2];
w = [0.225000000000000, ...
     0.132394152788506,0.132394152788506,0.132394152788506, ...
     0.125939180544827,0.125939180544827,0.125939180544827];
end

