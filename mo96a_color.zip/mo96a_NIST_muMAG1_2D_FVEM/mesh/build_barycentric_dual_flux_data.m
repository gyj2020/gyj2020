function [I,J,qcoef1,qcoef2,qcoef3] = ...
    build_barycentric_dual_flux_data(P,T,gx,gy)
%BUILD_BARYCENTRIC_DUAL_FLUX_DATA Exact flux data for vertex-centred FVEM.
%
% For each triangle and each local vertex i, the boundary of the local
% control-volume part consists of the two segments
%
%   midpoint(i,next) -> barycentre -> midpoint(i,previous).
%
% qcoef1/qcoef2/qcoef3 contain the coefficients of
%
%   integral_Gamma w_h grad(phi_j).n ds,
%
% with w_h represented by its three local nodal values.  Only dual edges
% inside primal triangles are assembled.  No physical-boundary segment is
% present, which is exactly the homogeneous Neumann flux treatment.

E = size(T,2);
I = zeros(9,E);
J = zeros(9,E);
r = 0;
for i = 1:3
    for j = 1:3
        r = r+1;
        I(r,:) = T(i,:);
        J(r,:) = T(j,:);
    end
end

X1 = P(:,T(1,:));
X2 = P(:,T(2,:));
X3 = P(:,T(3,:));
B = (X1+X2+X3)/3;

qcoef1 = zeros(9,E);
qcoef2 = zeros(9,E);
qcoef3 = zeros(9,E);

for i = 1:3
    inext = mod(i,3)+1;
    iprev = mod(i+1,3)+1;

    Xi = P(:,T(i,:));
    Xn = P(:,T(inext,:));
    Xp = P(:,T(iprev,:));
    Mnext = 0.5*(Xi+Xn);
    Mprev = 0.5*(Xi+Xp);

    % Oriented normal-times-length vectors, outward from the local part.
    edge1 = B-Mnext;
    nds1 = [edge1(2,:);-edge1(1,:)];
    edge2 = Mprev-B;
    nds2 = [edge2(2,:);-edge2(1,:)];

    c1 = zeros(3,E);
    c2 = zeros(3,E);
    for j = 1:3
        c1(j,:) = gx(j,:).*nds1(1,:) + gy(j,:).*nds1(2,:);
        c2(j,:) = gx(j,:).*nds2(1,:) + gy(j,:).*nds2(2,:);
    end

    % Exact line-integral averages of linear w_h on the two dual edges.
    w1 = zeros(3,1);
    w2 = zeros(3,1);
    w1(i) = 5/12;     w1(inext) = 5/12; w1(iprev) = 1/6;
    w2(i) = 5/12;     w2(inext) = 1/6;  w2(iprev) = 5/12;

    for j = 1:3
        rr = (i-1)*3+j;
        qcoef1(rr,:) = c1(j,:)*w1(1) + c2(j,:)*w2(1);
        qcoef2(rr,:) = c1(j,:)*w1(2) + c2(j,:)*w2(2);
        qcoef3(rr,:) = c1(j,:)*w1(3) + c2(j,:)*w2(3);
    end
end
end

