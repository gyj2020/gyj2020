function moments = precompute_dual_source_moments(P,T,area)
%PRECOMPUTE_DUAL_SOURCE_MOMENTS Integrate source fields over control cells.
%   The source separates into time factors and 13 spatial fields.  Their
%   control-volume integrals are computed once, avoiding quadrature inside
%   every backward-Euler time step.

N = size(P,2);
E = size(T,2);
moments = zeros(13,N);
[lambda,w] = triangle_quadrature_rule();

X1 = P(:,T(1,:));
X2 = P(:,T(2,:));
X3 = P(:,T(3,:));
B = (X1+X2+X3)/3;
area_sub = area/6;

for i = 1:3
    inext = mod(i,3)+1;
    iprev = mod(i+1,3)+1;
    Xi = P(:,T(i,:));
    Xn = P(:,T(inext,:));
    Xp = P(:,T(iprev,:));
    Mn = 0.5*(Xi+Xn);
    Mp = 0.5*(Xi+Xp);

    local_moment = zeros(13,E);
    for part = 1:2
        if part == 1
            Y1 = Xi; Y2 = Mn; Y3 = B;
        else
            Y1 = Xi; Y2 = B;  Y3 = Mp;
        end
        for q = 1:numel(w)
            xy = lambda(1,q)*Y1 + lambda(2,q)*Y2 + lambda(3,q)*Y3;
            fields = source_spatial_fields_LL(xy(1,:),xy(2,:));
            local_moment = local_moment + ...
                bsxfun(@times,fields,w(q)*area_sub);
        end
    end

    ids = T(i,:)';
    for r = 1:13
        moments(r,:) = moments(r,:) + ...
            accumarray(ids,local_moment(r,:)',[N 1])';
    end
end
end

