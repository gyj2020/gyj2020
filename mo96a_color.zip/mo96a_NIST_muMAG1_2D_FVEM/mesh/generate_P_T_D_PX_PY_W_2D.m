function data = generate_P_T_D_PX_PY_W_2D(nx,ny)
%GENERATE_P_T_D_PX_PY_W_2D Build all primal/dual data required by FVEM.
%
% The legacy file name is retained to match the supplied 2DLLGFVEM code.
% In this self-contained version all related arrays are returned in one
% structure.  The fields qcoef1--qcoef3 encode the barycentric-dual fluxes
% that played the role of D/PX/PY/W in the original implementation.

domain = [0 1 0 1];
[P,T] = generate_uniform_triangular_mesh_2D(nx,ny,domain);
[area,gx,gy] = compute_P1_triangle_geometry(P,T);

N = size(P,2);
E = size(T,2);
[I,J,qcoef1,qcoef2,qcoef3] = ...
    build_barycentric_dual_flux_data(P,T,gx,gy);

% Exact local matrix for (u_h,I_h^*v_h) on a barycentric dual mesh.
Mref = [22 7 7;7 22 7;7 7 22]/108;

% Consistent P1 mass and energy matrices are used only to measure errors.
MFref = [2 1 1;1 2 1;1 1 2]/12;

Mval = zeros(9,E);
MFval = zeros(9,E);
KEval = zeros(9,E);
r = 0;
for i = 1:3
    for j = 1:3
        r = r+1;
        Mval(r,:) = area*Mref(i,j);
        MFval(r,:) = area*MFref(i,j);
        KEval(r,:) = area.*(gx(i,:).*gx(j,:)+gy(i,:).*gy(j,:));
    end
end

M = sparse(I(:),J(:),Mval(:),N,N);
Mfem = sparse(I(:),J(:),MFval(:),N,N);
Kenergy = sparse(I(:),J(:),KEval(:),N,N);

% Genuine FVEM diffusion matrix: negative flux across the two internal
% dual edges of every local control-volume part.  Physical-boundary fluxes
% are zero and therefore are not added.
Kflux_val = -(qcoef1+qcoef2+qcoef3);
K = sparse(I(:),J(:),Kflux_val(:),N,N);

% Boundary-node metadata is included for diagnostics only; no row is fixed.
tol = 100*eps;
boundary_nodes = find(abs(P(1,:)-domain(1))<tol | ...
                      abs(P(1,:)-domain(2))<tol | ...
                      abs(P(2,:)-domain(3))<tol | ...
                      abs(P(2,:)-domain(4))<tol);

source_moments = precompute_dual_source_moments(P,T,area);

diffmat = K-Kenergy;
if nnz(diffmat) == 0
    flux_energy_difference = 0;
else
    flux_energy_difference = max(abs(nonzeros(diffmat)));
end

data = struct( ...
    'method','vertex-centred FVEM with barycentre-midpoint dual cells', ...
    'boundary_condition','homogeneous Neumann flux', ...
    'domain',domain,'nx',nx,'ny',ny, ...
    'P',P,'T',T,'Pb',P,'Tb',T,'N',N,'E',E, ...
    'area',area,'gx',gx,'gy',gy,'I',I,'J',J, ...
    'M',M,'Mfem',Mfem,'K',K,'Kenergy',Kenergy, ...
    'qcoef1',qcoef1,'qcoef2',qcoef2,'qcoef3',qcoef3, ...
    'source_moments',source_moments, ...
    'control_volume_area',full(sum(M,2)), ...
    'boundary_nodes',boundary_nodes, ...
    'flux_energy_difference',flux_energy_difference);
end

