function m0 = initialize_m0(P)
%INITIALIZE_M0 Nodal interpolation of the exact initial magnetization.
m0 = exact_solution_LL(P(1,:),P(2,:),0);
end

