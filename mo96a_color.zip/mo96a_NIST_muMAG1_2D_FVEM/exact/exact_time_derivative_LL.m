function mt = exact_time_derivative_LL(x,y,t)
%EXACT_TIME_DERIVATIVE_LL Exact time derivative of the manufactured solution.

x = x(:)';
y = y(:)';
xbar = x.^2.*(1-x).^2;
ybar = y.^2.*(1-y).^2;
phi = xbar.*ybar;

mt = [cos(phi)*cos(t); ...
      sin(phi)*cos(t); ...
      -ones(size(phi))*sin(t)];
end

