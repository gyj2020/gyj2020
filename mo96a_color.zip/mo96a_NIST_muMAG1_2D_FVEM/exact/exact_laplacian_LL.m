function lapm = exact_laplacian_LL(x,y,t)
%EXACT_LAPLACIAN_LL Exact componentwise Laplacian of the manufactured solution.

x = x(:)';
y = y(:)';
xbar = x.^2.*(1-x).^2;
ybar = y.^2.*(1-y).^2;
xbar_x = 2*x.*(1-x).*(1-2*x);
ybar_y = 2*y.*(1-y).*(1-2*y);
xbar_xx = 2-12*x+12*x.^2;
ybar_yy = 2-12*y+12*y.^2;

phi = xbar.*ybar;
phi_x = xbar_x.*ybar;
phi_y = xbar.*ybar_y;
lap_phi = xbar_xx.*ybar+xbar.*ybar_yy;
grad_phi_sq = phi_x.^2+phi_y.^2;
s = sin(t);

lapm = [s*(-sin(phi).*lap_phi-cos(phi).*grad_phi_sq); ...
        s*( cos(phi).*lap_phi-sin(phi).*grad_phi_sq); ...
        zeros(size(phi))];
end

