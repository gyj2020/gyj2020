function c = column_cross(a,b)
%COLUMN_CROSS Cross product of corresponding columns of two 3-by-N arrays.

if size(a,1) ~= 3 || size(b,1) ~= 3 || size(a,2) ~= size(b,2)
    error('Both inputs must be 3-by-N arrays with the same N.');
end
c = [a(2,:).*b(3,:)-a(3,:).*b(2,:); ...
     a(3,:).*b(1,:)-a(1,:).*b(3,:); ...
     a(1,:).*b(2,:)-a(2,:).*b(1,:)];
end

