function m = exact_solution_LL(x,y,t)
%EXACT_SOLUTION_LL Manufactured unit-length Landau--Lifshitz solution.

x = x(:)';
y = y(:)';
if numel(x) ~= numel(y)
    error('x and y must contain the same number of points.');
end

xbar = x.^2.*(1-x).^2;
ybar = y.^2.*(1-y).^2;
phi = xbar.*ybar;

m = [cos(phi)*sin(t); ...
     sin(phi)*sin(t); ...
     ones(size(phi))*cos(t)];
end

