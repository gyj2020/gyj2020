function [mx,my] = exact_gradient_LL(x,y,t)
%EXACT_GRADIENT_LL Exact spatial derivatives of the manufactured solution.

x = x(:)';
y = y(:)';
if numel(x) ~= numel(y)
    error('x and y must contain the same number of points.');
end

xbar = x.^2.*(1-x).^2;
ybar = y.^2.*(1-y).^2;
xbar_x = 2*x.*(1-x).*(1-2*x);
ybar_y = 2*y.*(1-y).*(1-2*y);

phi = xbar.*ybar;
phi_x = xbar_x.*ybar;
phi_y = xbar.*ybar_y;
s = sin(t);

mx = [-sin(phi).*s.*phi_x; ...
       cos(phi).*s.*phi_x; ...
       zeros(size(phi))];
my = [-sin(phi).*s.*phi_y; ...
       cos(phi).*s.*phi_y; ...
       zeros(size(phi))];
end

