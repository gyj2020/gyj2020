function F = source_spatial_fields_LL(x,y)
%SOURCE_SPATIAL_FIELDS_LL Spatial factors used in source precomputation.
% Rows are, in order:
%   cos(phi), sin(phi), L*cos(phi), L*sin(phi),
%   g*cos(phi), g*sin(phi), -g*sin(phi), g*cos(phi),
%   -L*sin(phi), L*cos(phi), 1, L, g,
% where L=Delta(phi) and g=|grad(phi)|^2.

x = x(:)';
y = y(:)';
xbar = x.^2.*(1-x).^2;
ybar = y.^2.*(1-y).^2;
xbar_x = 2*x.*(1-x).*(1-2*x);
ybar_y = 2*y.*(1-y).*(1-2*y);
xbar_xx = 2-12*x+12*x.^2;
ybar_yy = 2-12*y+12*y.^2;

phi = xbar.*ybar;
phi_x = xbar_x.*ybar;
phi_y = xbar.*ybar_y;
L = xbar_xx.*ybar+xbar.*ybar_yy;
g = phi_x.^2+phi_y.^2;
cp = cos(phi);
sp = sin(phi);

F = [cp;sp;L.*cp;L.*sp;g.*cp;g.*sp; ...
     -g.*sp;g.*cp;-L.*sp;L.*cp;ones(size(x));L;g];
end

