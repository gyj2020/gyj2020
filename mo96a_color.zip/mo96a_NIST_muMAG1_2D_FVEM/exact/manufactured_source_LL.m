function f = manufactured_source_LL(x,y,t,alpha)
%MANUFACTURED_SOURCE_LL Source in
%   m_t + m x Delta m + alpha*m x (m x Delta m) = f.

m = exact_solution_LL(x,y,t);
mt = exact_time_derivative_LL(x,y,t);
lapm = exact_laplacian_LL(x,y,t);
mxlap = column_cross(m,lapm);
f = mt+mxlap+alpha*column_cross(m,mxlap);
end

