clear; clc; close all; format long g;
%MAIN_DX Spatial convergence of the linearized BE vertex-centred FVEM.
%
% All four quantities are evaluated against the analytical exact solution,
% except that Length is the direct constraint defect ||1-|m_h^n|^2||_L2.

root_dir = fileparts(mfilename('fullpath'));
if isempty(root_dir), root_dir = pwd; end
addpath(genpath(root_dir));
result_dir = fullfile(root_dir,'results');
if ~exist(result_dir,'dir'), mkdir(result_dir); end

alpha = 0.01;
T = 5.0e-3;
dt_target = 1.0e-7;
nt = round(T/dt_target);
dt = T/nt;

nx = [8 16 24 32];
ny = nx;
h = 1./nx;

solver_options = struct( ...
    'linear_solver','gmres', ...
    'gmres_restart',30, ...
    'gmres_tolerance',1.0e-10, ...
    'gmres_maxit',15, ...
    'direct_fallback',true, ...
    'verbose',false);

ncase = numel(nx);
E = zeros(ncase,4);
solver_info = cell(ncase,1);

for k = 1:ncase
    fprintf('\nSpatial case %d/%d: h=1/%d, nt=%d, dt=%.15e\n', ...
        k,ncase,nx(k),nt,dt);
    data = generate_P_T_D_PX_PY_W_2D(nx(k),ny(k));
    [E(k,1),E(k,2),E(k,3),E(k,4),~,solver_info{k}] = ...
        LL_FVEM_2D_solver(data,T,nt,alpha,solver_options);
end

[rate,fit_order] = compute_convergence_rates(h,E);
labels = arrayfun(@(n)sprintf('1/%d',n),nx,'UniformOutput',false);
column_names = {'Linf','L2','H1','Length'};
print_convergence_table(labels,E,rate,fit_order,column_names, ...
    'SPATIAL ERRORS AGAINST THE ANALYTICAL EXACT SOLUTION');

figure_file = fullfile(result_dir,'spatial_convergence_LL_FVEM_Neumann.fig');
plot_spatial_convergence(h,E,figure_file);

result_file = fullfile(result_dir,'spatial_accuracy_LL_FVEM_Neumann.mat');
save(result_file,'alpha','T','dt_target','nt','dt','nx','ny','h', ...
    'E','rate','fit_order','solver_info');

text_file = fullfile(result_dir,'spatial_accuracy_LL_FVEM_Neumann.txt');
fid = fopen(text_file,'w');
if fid >= 0
    fprintf(fid,'alpha = %.16g, T = %.16g, nt = %d, dt = %.16e\n',alpha,T,nt,dt);
    fprintf(fid,'nx h Linf order_Linf L2 order_L2 H1 order_H1 Length order_Length\n');
    for k = 1:ncase
        fprintf(fid,'%d %.16e %.16e %.10g %.16e %.10g %.16e %.10g %.16e %.10g\n', ...
            nx(k),h(k),E(k,1),rate(k,1),E(k,2),rate(k,2), ...
            E(k,3),rate(k,3),E(k,4),rate(k,4));
    end
    fprintf(fid,'fitted_orders %.10g %.10g %.10g %.10g\n',fit_order);
    fclose(fid);
end

fprintf('\nSaved:\n  %s\n  %s\n  %s\n',result_file,figure_file,text_file);
