# NIST μMAG 标准问题 1 的二维磁滞回线程序

本文件说明统一二维 FVEM 数值内核。当前压缩包所对应的具体历史提交、
官方数据绘图命令及复现边界，请先阅读 `README_SUBMISSION_CN.md`。

## 1. 模拟对象

程序按照 NIST μMAG Standard Problem #1 设置：

- 薄片尺寸：`1 μm × 2 μm × 20 nm`；
- 交换常数：`A = 1.3e-11 J/m`；
- 饱和磁化强度：`Ms = 8.0e5 A/m`；
- 单轴各向异性：`Ku = 5.0e2 J/m^3`，易轴沿长边 `y`；
- 外场：`+50 mT -> -50 mT -> +50 mT`；
- 分别计算近短轴 `x` 和近长轴 `y` 的回线；
- 外场均相对名义轴逆时针偏转 `1°`；
- 扫场过程明确包含 `H=0`，保存下降支和上升支剩磁态。

NIST 原始说明：

- https://www.ctcms.nist.gov/~rdm/stdprob_1.html
- https://www.ctcms.nist.gov/~rdm/sub_guide1.html

## 2. 数学模型

采用厚度方向均匀的二维微磁近似，单位磁化向量为 `m=M/Ms`。约化有效场为

```text
h_eff = l_ex^2 Delta m + h_demag + h_ani + h_ext,
l_ex^2 = 2A/(mu0 Ms^2),
h_ani = 2Ku/(mu0 Ms^2) (m dot e_easy) e_easy.
```

每个外场值下，用阻尼型 Landau--Lifshitz 松弛求解

```text
partial_tau m = -m cross (m cross h_eff),   |m|=1,
```

直至 `max |m cross h_eff|` 和相邻迭代改变量同时满足阈值。该计算得到准静态亚稳分支；松弛参数不是物理时间步，因此代码用于 `M-H` 回线，而不是纳秒尺度动力学。

## 3. FVEM 与边界条件

- 原网格是 P1 三角形网格；
- 对偶控制体由“顶点—边中点—三角形重心”构成；
- 交换算子由对偶控制体内部边界通量直接组装；
- 物理边界交换通量为零，即 `partial_n m = 0`；
- 不删除边界自由度，也不进行 Dirichlet 行替换；
- 松弛迭代先计算阻尼型 LL 的切向下降方向，再用 `D+eta*l_ex^2*K` 进行交换预条件，其中 `D` 是对偶控制体面积对角阵，最后逐节点单位化。

## 4. 退磁场

程序使用厚度平均薄膜退磁张量。对二维波数 `k=(kx,ky)`，

```text
Nzz = (1-exp(-|k|t))/(|k|t),
Nij = ki*kj/|k|^2 * (1-Nzz),  i,j=x,y,
h_demag_hat = -N(k) m_hat.
```

磁体外部补零后再做 FFT，降低周期镜像的影响。`demag_pad_factor` 默认取 4。

这是与现有二维 FVEM 网格相匹配的厚度平均近似，不等同于完整三维 OOMMF/Newell 棱柱退磁计算。若用于论文中的定量 NIST 对照，应至少完成：

1. `nx,ny` 网格加密比较；
2. `demag_pad_factor=2,4,8` 补零敏感性比较；
3. 与 OOMMF 或其他三维基准程序的矫顽场、剩磁和剩磁畴结构比较。

## 5. 运行命令

在 MATLAB 中进入解压后的根目录，先执行：

```matlab
check_package
```

它会检查原精度程序和新增磁滞程序的全部依赖，并测试 FVEM 常数核、退磁张量及单位长度保持。

粗网格端到端测试：

```matlab
run_hysteresis_quick_test
```

正式运行：

```matlab
main_hysteresis_2D
```

主程序默认采用：

```matlab
param = default_mumag1_parameters('normal');
```

可改为：

```matlab
param = default_mumag1_parameters('refined');
% 或
param = default_mumag1_parameters('fine');
```

`fine` 网格约为 `5 nm × 5 nm`，接近本材料约 `5.69 nm` 的交换长度，但计算量显著增大。

## 6. 结果文件

提交专用主程序默认输出到 `results/simulation/`：

- `<code>_sim_hyx.dat`：近短轴完整回线，NIST 七列格式；
- `<code>_sim_hyy.dat`：近长轴完整回线，NIST 七列格式；
- `<code>_sim_rx1.dat`, `<code>_sim_rx2.dat`：短轴下降/上升支剩磁态；
- `<code>_sim_ry1.dat`, `<code>_sim_ry2.dat`：长轴下降/上升支剩磁态；
- `<code>_simulation_results.mat`：全部数值结果；
- `<code>_simulation_description.txt`：参数、方法、停止准则和结果摘要；
- MATLAB 原生 `.fig` 回线图、分量图、能量图和剩磁矢量图；程序不生成 PNG 文件。

回线文件每行依次为：

```text
Step  Hx  Hy  Hz  mx  my  mz
```

外场单位为 mT，磁化强度采用约化量 `M/Ms`。

## 7. 参数选择建议

| 预设 | 网格 | 外场步长 | 用途 |
|---|---:|---:|---|
| `quick` | 12×24 | 25 mT | 只检查程序是否完整可运行 |
| `normal` | 50×100 | 2 mT | 桌面演示及初步回线 |
| `refined` | 100×200 | 1 mT | 网格比较 |
| `fine` | 200×400 | 1 mT | 接近交换长度的昂贵二维计算 |

若某些外场点显示 `[max iterations]`，不要直接采用该点。可依次尝试增大 `max_relax_iter`、减小 `relax_step`，并检查 `torque_final` 是否下降。
