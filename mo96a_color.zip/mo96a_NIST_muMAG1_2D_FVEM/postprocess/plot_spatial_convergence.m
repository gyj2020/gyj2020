function plot_spatial_convergence(h,E,filename)
%PLOT_SPATIAL_CONVERGENCE Log-log plot of all four spatial quantities.

fig = figure('Color','w');
styles = {'-o','-s','-^','-d'};
for j = 1:4
    y = E(:,j);
    y(y <= 0) = NaN;
    loglog(h,y,styles{j},'LineWidth',1.5,'MarkerSize',6);
    hold on;
end

if E(1,2) > 0
    loglog(h,E(1,2)*(h(:)/h(1)).^2,'--k','LineWidth',1.2);
end
if E(1,3) > 0
    loglog(h,E(1,3)*(h(:)/h(1)),'-.k','LineWidth',1.2);
end
grid on; box on;
xlabel('$h$','Interpreter','latex');
ylabel('error','Interpreter','latex');
legend('$L^\infty$','$L^2$','$H^1$', ...
       '$\|1-|m_h^n|^2\|_{L^2}$', ...
       'second-order reference','first-order reference', ...
       'Interpreter','latex','Location','best');
title('Spatial convergence: homogeneous-Neumann FVEM', ...
      'Interpreter','latex');
set(gca,'FontName','Times New Roman','FontSize',12);

if nargin >= 3 && ~isempty(filename)
    savefig(fig,filename);
end
end
