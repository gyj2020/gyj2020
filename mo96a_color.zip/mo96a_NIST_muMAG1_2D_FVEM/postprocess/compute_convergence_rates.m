function [rate,fit_order] = compute_convergence_rates(step_size,E)
%COMPUTE_CONVERGENCE_RATES Adjacent and least-squares convergence orders.
%   Actual adjacent step ratios are used; they need not equal two.

step_size = step_size(:);
if size(E,1) ~= numel(step_size)
    error('The number of rows of E must equal numel(step_size).');
end

rate = nan(size(E));
for k = 2:numel(step_size)
    denominator = log(step_size(k-1)/step_size(k));
    for j = 1:size(E,2)
        if E(k-1,j) > 0 && E(k,j) > 0 && denominator ~= 0
            rate(k,j) = log(E(k-1,j)/E(k,j))/denominator;
        end
    end
end

fit_order = nan(1,size(E,2));
for j = 1:size(E,2)
    valid = step_size > 0 & E(:,j) > 0 & isfinite(E(:,j));
    if nnz(valid) >= 2
        p = polyfit(log(step_size(valid)),log(E(valid,j)),1);
        fit_order(j) = p(1);
    end
end
end

