function plot_temporal_convergence(dt,E,filename)
%PLOT_TEMPORAL_CONVERGENCE Log-log plot of all four temporal quantities.

fig = figure('Color','w');
styles = {'-o','-s','-^','-d'};
for j = 1:4
    y = E(:,j);
    y(y <= 0) = NaN;
    loglog(dt,y,styles{j},'LineWidth',1.5,'MarkerSize',6);
    hold on;
end

if E(1,1) > 0
    loglog(dt,E(1,1)*(dt(:)/dt(1)),'--k','LineWidth',1.2);
end
grid on; box on;
xlabel('$\Delta t$','Interpreter','latex');
ylabel('error','Interpreter','latex');
legend('$L^\infty$','$L^2$','$H^1$', ...
       '$\|1-|m_h^n|^2\|_{L^2}$','first-order reference', ...
       'Interpreter','latex','Location','best');
title('Temporal convergence: homogeneous-Neumann FVEM', ...
      'Interpreter','latex');
set(gca,'FontName','Times New Roman','FontSize',12);

if nargin >= 3 && ~isempty(filename)
    savefig(fig,filename);
end
end
