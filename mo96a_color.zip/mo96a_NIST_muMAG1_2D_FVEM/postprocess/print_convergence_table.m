function print_convergence_table(labels,E,rate,fit_order,column_names,title_text)
%PRINT_CONVERGENCE_TABLE Print four error columns and their orders.

if nargin < 6, title_text = 'CONVERGENCE RESULTS'; end
if numel(column_names) ~= size(E,2)
    error('column_names must have one entry for every column of E.');
end

fprintf('\n===============================================================================================\n');
fprintf('%s\n',title_text);
fprintf('===============================================================================================\n');
fprintf('%10s','step');
for j = 1:size(E,2)
    fprintf(' %14s %9s',column_names{j},'order');
end
fprintf('\n');

for k = 1:size(E,1)
    fprintf('%10s',labels{k});
    for j = 1:size(E,2)
        if isnan(rate(k,j))
            fprintf(' %14.7e %9s',E(k,j),'---');
        else
            fprintf(' %14.7e %9.5f',E(k,j),rate(k,j));
        end
    end
    fprintf('\n');
end

fprintf('%10s','fitted');
for j = 1:numel(fit_order)
    fprintf(' %14s %9.5f',' ',fit_order(j));
end
fprintf('\n');
fprintf('Length denotes ||1-|m_h^n|^2||_{L2}; it is not the H1 seminorm.\n');
end

