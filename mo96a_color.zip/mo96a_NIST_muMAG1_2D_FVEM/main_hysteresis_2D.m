%MAIN_HYSTERESIS_2D Run this package's report-informed FVEM simulation.
% For the official historical NIST curve without a long simulation, run
% main_reference_hysteresis instead.
main_simulation_hysteresis
