function [H1,H1seminorm] = get_H1_error(data,m,t)
%GET_H1_ERROR Full vector H1 error and, optionally, its gradient seminorm.

if size(m,1) ~= 3 || size(m,2) ~= data.N
    error('m must be a 3-by-data.N nodal array.');
end

T = data.T;
P = data.P;
area = data.area;

mh_x = m(:,T(1,:)).*data.gx(1,:) ...
     + m(:,T(2,:)).*data.gx(2,:) ...
     + m(:,T(3,:)).*data.gx(3,:);
mh_y = m(:,T(1,:)).*data.gy(1,:) ...
     + m(:,T(2,:)).*data.gy(2,:) ...
     + m(:,T(3,:)).*data.gy(3,:);

[lambda,w] = triangle_quadrature_rule();
seminorm_squared = 0;
for q = 1:numel(w)
    xq = lambda(1,q)*P(1,T(1,:)) ...
       + lambda(2,q)*P(1,T(2,:)) ...
       + lambda(3,q)*P(1,T(3,:));
    yq = lambda(1,q)*P(2,T(1,:)) ...
       + lambda(2,q)*P(2,T(2,:)) ...
       + lambda(3,q)*P(2,T(3,:));
    [me_x,me_y] = exact_gradient_LL(xq,yq,t);
    dgrad2 = sum((mh_x-me_x).^2+(mh_y-me_y).^2,1);
    seminorm_squared = seminorm_squared+w(q)*sum(area.*dgrad2);
end

H1seminorm = sqrt(max(seminorm_squared,0));
L2 = get_L2_error(data,m,t);
H1 = sqrt(L2^2+H1seminorm^2);
end

