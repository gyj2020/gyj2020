function Llen = get_length_error(data,m)
%GET_LENGTH_ERROR Compute ||1-|m_h|^2||_{L2(Omega)}.
%   Since m_h is P1, the squared defect is degree four.  The degree-five
%   triangle rule used here integrates it exactly (up to roundoff).

if size(m,1) ~= 3 || size(m,2) ~= data.N
    error('m must be a 3-by-data.N nodal array.');
end

T = data.T;
area = data.area;
[lambda,w] = triangle_quadrature_rule();
value = 0;

for q = 1:numel(w)
    mh = lambda(1,q)*m(:,T(1,:)) ...
       + lambda(2,q)*m(:,T(2,:)) ...
       + lambda(3,q)*m(:,T(3,:));
    defect = 1-sum(mh.^2,1);
    value = value+w(q)*sum(area.*defect.^2);
end

Llen = sqrt(max(value,0));
end

