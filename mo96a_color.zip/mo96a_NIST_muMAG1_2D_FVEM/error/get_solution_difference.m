function [Linf,L2,H1,H1seminorm] = ...
    get_solution_difference(data,m1,m2)
%GET_SOLUTION_DIFFERENCE Norms of two P1 vector fields on the same mesh.
%   Used by main_dt to remove the fixed spatial error.

if ~isequal(size(m1),[3,data.N]) || ~isequal(size(m2),[3,data.N])
    error('m1 and m2 must both be 3-by-data.N nodal arrays.');
end

d = m1-m2;
Linf = max(sqrt(sum(d.^2,1)));
L2_squared = 0;
H1semi_squared = 0;

for c = 1:3
    dc = d(c,:)';
    L2_squared = L2_squared+real(dc'*(data.Mfem*dc));
    H1semi_squared = H1semi_squared+real(dc'*(data.Kenergy*dc));
end

L2 = sqrt(max(L2_squared,0));
H1seminorm = sqrt(max(H1semi_squared,0));
H1 = sqrt(L2_squared+H1semi_squared);
end

