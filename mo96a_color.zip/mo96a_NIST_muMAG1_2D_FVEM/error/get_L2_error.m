function L2 = get_L2_error(data,m,t)
%GET_L2_ERROR Vector L2 error of the continuous P1 numerical solution.

if size(m,1) ~= 3 || size(m,2) ~= data.N
    error('m must be a 3-by-data.N nodal array.');
end

P = data.P;
T = data.T;
area = data.area;
[lambda,w] = triangle_quadrature_rule();
value = 0;

for q = 1:numel(w)
    xq = lambda(1,q)*P(1,T(1,:)) ...
       + lambda(2,q)*P(1,T(2,:)) ...
       + lambda(3,q)*P(1,T(3,:));
    yq = lambda(1,q)*P(2,T(1,:)) ...
       + lambda(2,q)*P(2,T(2,:)) ...
       + lambda(3,q)*P(2,T(3,:));
    mh = lambda(1,q)*m(:,T(1,:)) ...
       + lambda(2,q)*m(:,T(2,:)) ...
       + lambda(3,q)*m(:,T(3,:));
    me = exact_solution_LL(xq,yq,t);
    d2 = sum((mh-me).^2,1);
    value = value+w(q)*sum(area.*d2);
end

L2 = sqrt(max(value,0));
end

