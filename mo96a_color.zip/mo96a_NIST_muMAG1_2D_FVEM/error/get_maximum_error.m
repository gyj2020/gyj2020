function Linf = get_maximum_error(data,m,t)
%GET_MAXIMUM_ERROR Maximum nodal Euclidean-vector error.

if size(m,1) ~= 3 || size(m,2) ~= data.N
    error('m must be a 3-by-data.N nodal array.');
end
m_exact = exact_solution_LL(data.P(1,:),data.P(2,:),t);
d = m-m_exact;
Linf = max(sqrt(sum(d.^2,1)));
end

