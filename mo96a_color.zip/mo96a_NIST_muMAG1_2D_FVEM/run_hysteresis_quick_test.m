function run_hysteresis_quick_test()
%RUN_HYSTERESIS_QUICK_TEST Coarse end-to-end test of both NIST loops.
%
% This verifies execution and file generation.  Its coarse mesh and field
% spacing are intentionally not suitable for reporting physical values.

root_dir = fileparts(mfilename('fullpath'));
addpath(genpath(root_dir));
code = current_submission_code();
param = submission_parameters(code,'quick');
param.output_dir = fullfile(root_dir,'results','hysteresis_quick');

fprintf('Running coarse x- and y-loop package test...\n');
result_x = hysteresis_FVEM_2D_solver(param,'x');
result_y = hysteresis_FVEM_2D_solver(param,'y');
plot_hysteresis_results_2D(result_x,result_y,param);
save(fullfile(param.output_dir,'quick_hysteresis_results.mat'), ...
    'param','result_x','result_y');
write_mumag1_description(param,result_x,result_y);
fprintf('Quick hysteresis test completed: %s\n',param.output_dir);
end
