clear; clc; close all; format long g;
%MAIN_DT Temporal convergence of the linearized BE vertex-centred FVEM.
%
% The first three errors are pure temporal errors obtained by comparison
% with a fine-time solution on the same mesh.  The fourth quantity is the
% unit-length defect of each tested numerical solution itself:
%                  ||1-|m_h^n|^2||_{L2}.

root_dir = fileparts(mfilename('fullpath'));
if isempty(root_dir), root_dir = pwd; end
addpath(genpath(root_dir));
result_dir = fullfile(root_dir,'results');
if ~exist(result_dir,'dir'), mkdir(result_dir); end

alpha = 0.01;
T = 5.0e-3;

% Fixed spatial grid.
nx = 100;
ny = 100;
data = generate_P_T_D_PX_PY_W_2D(nx,ny);

% Requested temporal partitions and fine-time reference.
nt = [40 60 100 160];
dt = T./nt;
nt_ref = 2560;
dt_ref = T/nt_ref;

solver_options = struct( ...
    'linear_solver','gmres', ...
    'gmres_restart',30, ...
    'gmres_tolerance',1.0e-10, ...
    'gmres_maxit',15, ...
    'direct_fallback',true, ...
    'verbose',false);

fprintf('Computing fine-time reference: nx=ny=%d, nt_ref=%d, dt_ref=%.15e\n', ...
    nx,nt_ref,dt_ref);
[~,~,~,Llen_ref,m_ref,info_ref] = ...
    LL_FVEM_2D_solver(data,T,nt_ref,alpha,solver_options);

ncase = numel(nt);
E = zeros(ncase,4);       % pure-time Linf/L2/H1, then length defect
Eexact = zeros(ncase,4);  % diagnostic total errors against exact solution
solver_info = cell(ncase,1);

for k = 1:ncase
    fprintf('\nTemporal case %d/%d: nt=%d, dt=%.15e\n', ...
        k,ncase,nt(k),dt(k));
    [Eexact(k,1),Eexact(k,2),Eexact(k,3),Eexact(k,4),m_num,solver_info{k}] = ...
        LL_FVEM_2D_solver(data,T,nt(k),alpha,solver_options);

    [E(k,1),E(k,2),E(k,3)] = ...
        get_solution_difference(data,m_num,m_ref);
    E(k,4) = Eexact(k,4);
end

[rate,fit_order] = compute_convergence_rates(dt,E);
labels = arrayfun(@(n)sprintf('T/%d',n),nt,'UniformOutput',false);
column_names = {'Linf','L2','H1','Length'};
print_convergence_table(labels,E,rate,fit_order,column_names, ...
    'TEMPORAL ERRORS (first three against fine-time reference)');

figure_file = fullfile(result_dir,'temporal_convergence_LL_FVEM_Neumann.fig');
plot_temporal_convergence(dt,E,figure_file);

result_file = fullfile(result_dir,'temporal_accuracy_LL_FVEM_Neumann.mat');
save(result_file,'alpha','T','nx','ny','nt','dt','nt_ref','dt_ref', ...
    'E','Eexact','rate','fit_order','Llen_ref','info_ref','solver_info');

text_file = fullfile(result_dir,'temporal_accuracy_LL_FVEM_Neumann.txt');
fid = fopen(text_file,'w');
if fid >= 0
    fprintf(fid,'alpha = %.16g, T = %.16g, nx = %d, ny = %d, nt_ref = %d\n', ...
        alpha,T,nx,ny,nt_ref);
    fprintf(fid,'nt dt Linf order_Linf L2 order_L2 H1 order_H1 Length order_Length\n');
    for k = 1:ncase
        fprintf(fid,'%d %.16e %.16e %.10g %.16e %.10g %.16e %.10g %.16e %.10g\n', ...
            nt(k),dt(k),E(k,1),rate(k,1),E(k,2),rate(k,2), ...
            E(k,3),rate(k,3),E(k,4),rate(k,4));
    end
    fprintf(fid,'fitted_orders %.10g %.10g %.10g %.10g\n',fit_order);
    fclose(fid);
end

fprintf('\nSaved:\n  %s\n  %s\n  %s\n',result_file,figure_file,text_file);
