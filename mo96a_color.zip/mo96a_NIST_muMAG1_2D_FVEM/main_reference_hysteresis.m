clear; clc; close all; format long g;
%MAIN_REFERENCE_HYSTERESIS Plot official loops and remanent vector fields.

root_dir = fileparts(mfilename('fullpath'));
addpath(genpath(root_dir));
code = current_submission_code();
reference = load_nist_submission(root_dir,code);
output_dir = fullfile(root_dir,'results','reference');

plot_nist_reference_loops(reference,output_dir);
save(fullfile(output_dir,[code '_reference_data.mat']),'reference');

% The same entry point also creates the official NIST vector images at
% remanence from the bundled rx/ry spatial magnetization data.
main_reference_remanence_vectors

fprintf('\n%s official NIST curves plotted with plot().\n',code);
fprintf('Openable FIG files are in:\n  %s\n',output_dir);
fprintf('Vector Images at Remanence are in the remanence subfolder.\n');
fprintf('No PNG file is generated.\n');
