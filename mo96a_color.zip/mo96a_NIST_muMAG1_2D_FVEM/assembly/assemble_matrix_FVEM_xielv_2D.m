function Q = assemble_matrix_FVEM_xielv_2D(data,w)
%ASSEMBLE_MATRIX_FVEM_XIELV_2D Coefficient-dependent dual-flux matrix.
%   Q(i,j)=integral_{partial V_i inside Omega} w_h grad(phi_j).n ds.
%   w contains one scalar nodal value at each primal-mesh vertex.

w = w(:)';
if numel(w) ~= data.N
    error('w must contain exactly data.N nodal values.');
end

T = data.T;
W1 = w(T(1,:));
W2 = w(T(2,:));
W3 = w(T(3,:));
val = bsxfun(@times,data.qcoef1,W1) ...
    + bsxfun(@times,data.qcoef2,W2) ...
    + bsxfun(@times,data.qcoef3,W3);
Q = sparse(data.I(:),data.J(:),val(:),data.N,data.N);
end

