function K = assemble_matrix_FVEM_2D(data)
%ASSEMBLE_MATRIX_FVEM_2D Return the constant-coefficient FVEM flux matrix.
%
% K(i,j) is assembled from
%   - integral_{partial V_i inside Omega} grad(phi_j).n ds.
% The data were constructed edge by edge on the barycentric dual mesh.
% Physical-boundary fluxes are absent because partial_n m=0.

K = data.K;
end

