function M = assemble_matrix_M_FVEM_2D(data)
%ASSEMBLE_MATRIX_M_FVEM_2D FVEM control-volume mass matrix.
%   M(i,j)=(phi_j,I_h^*phi_i)=integral_{V_i} phi_j dx.

M = data.M;
end

