function F = assemble_vector_FVEM_2D(data,t,alpha)
%ASSEMBLE_VECTOR_FVEM_2D Assemble integral_{V_i} f(x,t) dx.
%   The 13 spatial moments were precomputed over the actual dual control
%   volumes.  Only inexpensive time factors are evaluated here.

s = sin(t);
c = cos(t);
q = data.source_moments;

% These expressions are the componentwise expansion of
% f=m_t+m x Delta(m)+alpha*m x (m x Delta(m)).
f1 = c*q(1,:) - c*s*q(3,:) + alpha*s*c^2*q(5,:) ...
   - c*s*q(7,:) - alpha*s*q(9,:);
f2 = c*q(2,:) - c*s*q(4,:) + alpha*s*c^2*q(6,:) ...
   - c*s*q(8,:) - alpha*s*q(10,:);
f3 = -s*q(11,:) + s^2*q(12,:) - alpha*s^2*c*q(13,:);

F = [f1(:);f2(:);f3(:)];
end

