function b = assemble_vector_nonlinear_FVEM_2D(data,m,alpha)
%ASSEMBLE_VECTOR_NONLINEAR_FVEM_2D Assemble
%   alpha*integral_{V_i} |grad(m_h)|^2 m_h dx.
%
% grad(m_h) is constant on each P1 triangle.  The remaining integral of
% m_h over each local control-volume part is evaluated exactly.

if size(m,1) ~= 3 || size(m,2) ~= data.N
    error('m must be a 3-by-data.N nodal array.');
end

T = data.T;
E = data.E;
N = data.N;
area = data.area;

Gx = zeros(3,E);
Gy = zeros(3,E);
for c = 1:3
    Gx(c,:) = m(c,T(1,:)).*data.gx(1,:) ...
            + m(c,T(2,:)).*data.gx(2,:) ...
            + m(c,T(3,:)).*data.gx(3,:);
    Gy(c,:) = m(c,T(1,:)).*data.gy(1,:) ...
            + m(c,T(2,:)).*data.gy(2,:) ...
            + m(c,T(3,:)).*data.gy(3,:);
end
grad_squared = sum(Gx.^2+Gy.^2,1);

bc = zeros(3,N);
for i = 1:3
    j = mod(i,3)+1;
    k = mod(i+1,3)+1;
    ids = T(i,:)';
    for c = 1:3
        % Integral of a P1 function over the two subtriangles belonging to
        % local vertex i: area*(22*m_i+7*m_j+7*m_k)/108.
        mint = area.*(22*m(c,T(i,:))+7*m(c,T(j,:))+7*m(c,T(k,:)))/108;
        val = alpha*grad_squared.*mint;
        bc(c,:) = bc(c,:) + accumarray(ids,val',[N 1])';
    end
end

b = [bc(1,:)';bc(2,:)';bc(3,:)'];
end

