%MAIN_MO96A_COLORED_REMANENCE Generate coloured mo96a remanent images.
root_dir = fileparts(mfilename('fullpath'));
addpath(root_dir);
main_reference_colored_remanence
