function test_nist_reference_reader()
%TEST_NIST_REFERENCE_READER Check bundled official loop data and unit logic.

root_dir = fileparts(fileparts(mfilename('fullpath')));
code = current_submission_code();
reference = load_nist_submission(root_dir,code);

switch lower(code)
    case {'du96a','fr96a'}
        expected = 396;
    case 'lu96a'
        expected = 123;
    case 'mo96a'
        expected = 133;
    case 'pb97a'
        expected = 200;
    otherwise
        error('Unexpected package code: %s',code);
end

assert(reference.x.record_count == expected);
assert(reference.y.record_count == expected);
assert(all(isfinite(reference.x.Hparallel_mT)));
assert(all(isfinite(reference.y.Hparallel_mT)));
assert(all(isfinite(reference.x.m_parallel)));
assert(all(isfinite(reference.y.m_parallel)));
assert(max(abs(reference.x.Hparallel_mT)) > 49.0);
assert(max(abs(reference.x.Hparallel_mT)) < 52.0);
assert(max(abs(reference.y.Hparallel_mT)) > 49.0);
assert(max(abs(reference.y.Hparallel_mT)) < 52.0);
assert(abs(norm(reference.x.field_direction)-1) < 1.0e-12);
assert(abs(norm(reference.y.field_direction)-1) < 1.0e-12);

fprintf('NIST reference reader test passed for %s (%d records/loop).\n', ...
    code,expected);
end
