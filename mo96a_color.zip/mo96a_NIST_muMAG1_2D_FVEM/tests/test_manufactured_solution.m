function test_manufactured_solution()
%TEST_MANUFACTURED_SOLUTION Unit length, source split, and Neumann checks.

alpha = 0.01;
t = 3.7e-3;
x = [0.13 0.37 0.71 0.92];
y = [0.21 0.58 0.44 0.83];
m = exact_solution_LL(x,y,t);
unit_error = max(abs(sum(m.^2,1)-1));

f_direct = manufactured_source_LL(x,y,t,alpha);
q = source_spatial_fields_LL(x,y);
s = sin(t); c = cos(t);
f_split = [ ...
    c*q(1,:) - c*s*q(3,:) + alpha*s*c^2*q(5,:) - c*s*q(7,:) - alpha*s*q(9,:); ...
    c*q(2,:) - c*s*q(4,:) + alpha*s*c^2*q(6,:) - c*s*q(8,:) - alpha*s*q(10,:); ...
    -s*q(11,:) + s^2*q(12,:) - alpha*s^2*c*q(13,:)];
source_error = max(max(abs(f_direct-f_split)));

r = linspace(0,1,11);
[mx0,~] = exact_gradient_LL(zeros(size(r)),r,t);
[mx1,~] = exact_gradient_LL(ones(size(r)),r,t);
[~,my0] = exact_gradient_LL(r,zeros(size(r)),t);
[~,my1] = exact_gradient_LL(r,ones(size(r)),t);
neumann_error = max([max(abs(mx0(:))),max(abs(mx1(:))), ...
                      max(abs(my0(:))),max(abs(my1(:)))]);

assert(unit_error < 5.0e-14,'Exact solution is not unit length.');
assert(source_error < 5.0e-13,'Separated manufactured source is inconsistent.');
assert(neumann_error < 5.0e-14,'Exact solution violates homogeneous Neumann data.');
fprintf('Manufactured-solution test passed (unit length, source, Neumann BC).\n');
end

