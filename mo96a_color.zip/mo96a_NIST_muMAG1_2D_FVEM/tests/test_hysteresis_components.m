function test_hysteresis_components()
%TEST_HYSTERESIS_COMPONENTS Small FVEM/field/relaxation integration test.

param = default_mumag1_parameters('quick');
param.nx = 4;
param.ny = 8;
param.max_relax_iter = 6;
param.min_relax_iter = 1;
param.check_every = 1;
param.tol_torque = 0;
param.tol_change = 0;
param.verbose_relax = false;

Lx = param.Lx_m/param.length_scale_m;
Ly = param.Ly_m/param.length_scale_m;
data = generate_FVEM_rectangle_2D(param.nx,param.ny,Lx,Ly);
M = assemble_matrix_M_FVEM_2D(data);
K = assemble_matrix_FVEM_2D(data);
mlump = full(sum(M,2));
D = spdiags(mlump,0,data.N,data.N);
lex2 = param.exchange_coefficient;

constant_kernel = norm(K*ones(data.N,1),inf);
assert(constant_kernel < 1e-11, ...
    'The homogeneous-Neumann FVEM exchange matrix lost its constant kernel.');

ctx = struct('param',param,'data',data,'M',M,'D',D,'K',K, ...
    'mlump',mlump,'lex2',lex2, ...
    'kappa',param.anisotropy_coefficient, ...
    'easy',param.easy_axis/norm(param.easy_axis), ...
    'exchange_solver',prepare_exchange_solver( ...
        D,K,param.relax_step*lex2,param), ...
    'demag_grid',prepare_demag_fft_2D(param));

angle = param.cant_deg*pi/180;
m0 = repmat([cos(angle);sin(angle);0],1,data.N);
h_ext = (0.05/(param.mu0*param.Ms))*[cos(angle);sin(angle);0];
[m,info] = relax_field_FVEM_2D(m0,h_ext,ctx);

length_error = max(abs(sqrt(sum(m.^2,1))-1));
assert(all(isfinite(m(:))) && isfinite(info.energy.total), ...
    'The relaxation returned NaN or Inf.');
assert(length_error < 5e-13,'Nodal unit length was not maintained.');
assert(info.iterations == param.max_relax_iter, ...
    'The forced fixed-iteration integration test stopped unexpectedly.');

fprintf(['Hysteresis component test passed (K*1 %.3e, ' ...
    'length residual %.3e).\n'],constant_kernel,length_error);
end
