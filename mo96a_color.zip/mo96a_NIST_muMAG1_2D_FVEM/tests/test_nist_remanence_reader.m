function test_nist_remanence_reader()
%TEST_NIST_REMANENCE_READER Validate bundled NIST remanent vector fields.

root_dir = fileparts(fileparts(mfilename('fullpath')));
code = current_submission_code();
remanence = load_nist_remanence_states(root_dir,code);

switch lower(code)
    case 'du96a'
        expected_records = 814;
        expected_tags = {'rx1','ry1','rx2','ry2'};
    case 'fr96a'
        expected_records = 800;
        expected_tags = {'rx1','ry1','rx2','ry2'};
    case 'lu96a'
        expected_records = 1800;
        expected_tags = {'rx1','ry1'};
    case {'mo96a','pb97a'}
        expected_records = 5000;
        expected_tags = {'rx1','ry1'};
    otherwise
        error('Unexpected package code: %s',code);
end

assert(numel(remanence.available_tags) == numel(expected_tags));
for k = 1:numel(expected_tags)
    tag = expected_tags{k};
    assert(isfield(remanence,tag));
    state = remanence.(tag);
    assert(state.record_count == expected_records);
    assert(size(state.position_um,2) == 3);
    assert(size(state.m,2) == 3);
    assert(all(isfinite(state.position_um(:))));
    assert(all(isfinite(state.m(:))));
    assert(min(state.position_um(:,1)) >= -1.0e-12);
    assert(max(state.position_um(:,1)) <= 1.0+1.0e-12);
    assert(min(state.position_um(:,2)) >= -1.0e-12);
    assert(max(state.position_um(:,2)) <= 2.0+1.0e-12);
    assert(state.max_unit_length_error < 2.0e-3);
end

fprintf('NIST remanence reader test passed for %s (%d state files).\n', ...
    code,numel(expected_tags));
end
