function test_demag_fft_2D()
%TEST_DEMAG_FFT_2D Algebraic and physical checks on thin-film demag FFT.

param = default_mumag1_parameters('quick');
param.nx = 8;
param.ny = 16;
grid = prepare_demag_fft_2D(param);

trace_error = max(abs(grid.Nxx(:)+grid.Nyy(:)+grid.Nzz(:)-1));
assert(trace_error < 2e-13,'The demag tensor trace is not one.');
assert(max(abs(grid.Nxy(:))) <= 0.5+100*eps, ...
    'The cross demag multiplier is outside its spectral bound.');

N = (param.nx+1)*(param.ny+1);
zero_field = demag_field_fft_2D(zeros(3,N),grid);
assert(norm(zero_field,'fro') == 0,'Zero magnetization gave nonzero field.');

mx = zeros(3,N); mx(1,:) = 1;
my = zeros(3,N); my(2,:) = 1;
hx = demag_field_fft_2D(mx,grid);
hy = demag_field_fft_2D(my,grid);
assert(all(isfinite(hx(:))) && all(isfinite(hy(:))), ...
    'The demag calculation returned NaN or Inf.');
assert(mean(hx(1,:)) < 0 && mean(hy(2,:)) < 0, ...
    'A uniform in-plane moment must have an opposing average demag field.');
assert(abs(mean(hx(1,:))) > abs(mean(hy(2,:))), ...
    'The short axis should have a larger average demag factor.');

fprintf('2-D demag FFT test passed (trace residual %.3e).\n',trace_error);
end

