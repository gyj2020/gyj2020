function test_FVEM_assembly()
%TEST_FVEM_ASSEMBLY Algebraic checks specific to the dual-flux assembly.

data = generate_P_T_D_PX_PY_W_2D(4,3);
K = assemble_matrix_FVEM_2D(data);
M = assemble_matrix_M_FVEM_2D(data);
Qone = assemble_matrix_FVEM_xielv_2D(data,ones(1,data.N));

scaleK = max(1,norm(K,'fro'));
constant_flux_residual = norm(Qone+K,'fro')/scaleK;
constant_kernel_residual = norm(K*ones(data.N,1),inf)/scaleK;
domain_area_error = abs(sum(full(sum(M,2)))-1);
flux_crosscheck = data.flux_energy_difference/scaleK;

assert(constant_flux_residual < 5.0e-13, ...
    'FVEM check failed: Q(1) must equal -K.');
assert(constant_kernel_residual < 5.0e-13, ...
    'FVEM check failed: constants must be in the Neumann kernel of K.');
assert(domain_area_error < 5.0e-13, ...
    'FVEM check failed: control-volume areas do not sum to |Omega|=1.');
assert(flux_crosscheck < 5.0e-13, ...
    'FVEM check failed: constant dual flux cross-check is inconsistent.');
assert(numel(data.boundary_nodes) == 2*(data.nx+data.ny), ...
    'FVEM check failed: boundary-node metadata is inconsistent.');

fprintf('FVEM assembly test passed (dual flux, mass, Neumann kernel).\n');
end
