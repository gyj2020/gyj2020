# mo96a：NIST muMAG 标准问题 1 磁滞回线与剩磁矢量图 MATLAB 完整工程

## 本程序包包含什么

这是一个可独立运行的完整工程，包含：

1. NIST 官方 `mo96ahyx/hyy.dat` 回线数据及 `mo96arx/ry1.dat` 剩磁场数据；
2. 兼容五/六列剩磁文件及六/七列回线文件的读取程序；
3. 使用 `plot` 绘制回线、使用 `quiver` 绘制官方剩磁矢量场的程序；
4. 顶点中心有限体积元（FVEM）交换场、齐次 Neumann 交换边界；
5. 厚度平均薄膜退磁场、各向异性场、外场和 LL 阻尼松弛；
6. 按公开报告设置网格、初始态和官方扫场序列的二维重算程序；
7. 网格、装配、求解、误差、后处理和测试等全部子包。

当前提交的公开报告摘要：

- 三分量磁化、二维网格；
- 5000 个单元，单元尺寸为 `20 x 20 x 20 nm`；
- 均匀初态，短轴/长轴各 133 个场状态，外场偏转 `+1` 度；
- 退磁场采用 FFT；
- 报告矫顽场：短轴 `2.5 mT`，长轴 `4.9 mT`。

## 最快得到官方磁滞回线 FIG

在 MATLAB 中进入解压后的工程根目录，运行：

```matlab
check_package
main_reference_hysteresis
```

也可直接运行同义入口：

```matlab
main_mo96a_hysteresis
```

生成文件位于 `results/reference/`：

- `mo96a_reference_hysteresis_both_axes.fig`；
- `mo96a_reference_short_axis_components.fig`；
- `mo96a_reference_long_axis_components.fig`；
- `mo96a_reference_data.mat`。

全部回线均由 `plot` 绘制，再用 `savefig` 保存；代码不写出 PNG。
保存前图窗属性固定为 `Visible='on'`，因此可在 MATLAB 文件浏览器中
双击 `.fig` 直接显示。也可以使用：

```matlab
openfig(fullfile('results','reference', ...
    'mo96a_reference_hysteresis_both_axes.fig'),'new','visible');
```

## 输出官方 Vector Images at Remanence

运行 `main_reference_hysteresis` 或 `main_mo96a_hysteresis` 时会自动生成
剩磁矢量图。若只需要矢量图，可运行：

```matlab
main_mo96a_remanence_vectors
```

图像保存在 `results/reference/remanence/`：

- `mo96a_Vector_Images_at_Remanence.fig`：长轴与短轴主剩磁态组合图；
- `mo96a_remanence_long_axis_ry1.fig`：长轴剩磁态；
- `mo96a_remanence_short_axis_rx1.fig`：短轴剩磁态。

矢量图直接读取官方 5000 个单元的磁化数据，并按 NIST 网页显示方式将
位置与磁化箭头同时逆时针旋转 `90` 度；绘图时规则抽取为 1250 支箭头，
与原提交的矢量数据密度一致。输出只使用 MATLAB 原生 `.fig`，不生成 PNG。

## 生成与示例一致的彩色剩磁图

若只生成彩色图片，运行：

```matlab
main_mo96a_colored_remanence
```

`main_mo96a_hysteresis` 和 `main_mo96a_remanence_vectors` 也会自动生成这些
彩色图。主要文件为：

- `mo96a_Colored_Vector_Images_at_Remanence.fig`：短轴与长轴组合图；
- `mo96a_colored_short_x_descending_remanence.fig`；
- `mo96a_colored_long_y_descending_remanence.fig`。

背景颜色表示 `theta=atan2(m_y,m_x)`，固定色标范围为 `[-pi,pi]`，采用
`hsv(256)` 色图；黑色箭头表示 `(m_x,m_y)`。彩色背景按照 NIST 的最近点
规则映射到 `100 x 200` 公共网格，坐标保持 `x=[0,1]`、`y=[0,2] um`。
全部结果仍直接保存为 MATLAB `.fig`，不输出 PNG。

## 运行二维 FVEM 重算

先进行小网格依赖和端到端检查：

```matlab
run_hysteresis_quick_test
```

再运行正式的、按报告信息配置的二维比较：

```matlab
main_hysteresis_2D
```

正式计算会同时计算近短轴和近长轴两条完整路径，并输出到
`results/simulation/`。网格越细、官方场点越多，耗时越长。

## 必须区分的两类结果

- `results/reference/` 是随包提供的 NIST 官方历史数值，运行绘图程序即可
  精确重现网站数据曲线。
- `results/simulation/` 是本包统一二维 FVEM 薄膜模型的重新计算，用来与
  官方数据比较。

历史 `mo96a` 与本包都采用 FFT 类退磁计算，并使用 `50 x 100` 的
`20 nm` 名义单元布局；但历史提交的具体离散核、边界处理和求解器并未
全部公开。本包仍是三角网格顶点中心 FVEM 的独立重算，而非原代码复制。

因此，二维 FVEM 结果应称为“参考该报告设置的重新计算”，不能称为历史
匿名提交代码的逐行复现。

## NIST 标准参数

- 几何：`1 um x 2 um x 20 nm`；
- `A = 1.3e-11 J/m`；
- `Ms = 8.0e5 A/m`；
- `Ku = 5.0e2 J/m^3`，易轴沿长轴 y；
- 外场约从 `+50 mT` 到 `-50 mT` 再返回；
- 近短轴和近长轴均计算，名义方向偏转约 1 度。

## 来源

- 标准问题说明：
  https://www.ctcms.nist.gov/~rdm/stdprob_1.html
- 提交格式：
  https://www.ctcms.nist.gov/~rdm/sub_guide1.html
- 官方剩磁矢量图比较：
  https://www.ctcms.nist.gov/~rdm/std1/vectorcompare.html
- 本提交报告：
  https://www.ctcms.nist.gov/~rdm/std1/mo96/mo96a.html
- 本提交原始数据：
  https://www.ctcms.nist.gov/~rdm/std1/mo96/mo96a.tar.gz
