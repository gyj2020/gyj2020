function code = current_submission_code()
%CURRENT_SUBMISSION_CODE Fixed NIST submission represented by this package.
code = 'mo96a';
end
