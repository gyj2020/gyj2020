clear; clc; format long g;
%RUN_QUICK_TEST Small, fast end-to-end run before the full convergence tests.

root_dir = fileparts(mfilename('fullpath'));
if isempty(root_dir), root_dir = pwd; end
addpath(genpath(root_dir));

check_package();

alpha = 0.01;
T = 5.0e-4;
data = generate_P_T_D_PX_PY_W_2D(6,6);
options = struct('linear_solver','gmres','gmres_restart',20, ...
    'gmres_tolerance',1.0e-10,'gmres_maxit',10, ...
    'direct_fallback',true,'verbose',false);

[Linf,L2,H1,Llen,m,info] = LL_FVEM_2D_solver(data,T,5,alpha,options); %#ok<ASGLU>

fprintf('\nQuick end-to-end test completed.\n');
fprintf('  Linf   = %.8e\n',Linf);
fprintf('  L2     = %.8e\n',L2);
fprintf('  H1     = %.8e\n',H1);
fprintf('  Length = %.8e  (||1-|m_h|^2||_L2)\n',Llen);
fprintf('  Runtime= %.3f s\n',info.elapsed_seconds);

if any(~isfinite([Linf,L2,H1,Llen]))
    error('Quick test failed: a non-finite error value was produced.');
end
fprintf('Quick test passed. You can now run main_dt or main_dx.\n');
