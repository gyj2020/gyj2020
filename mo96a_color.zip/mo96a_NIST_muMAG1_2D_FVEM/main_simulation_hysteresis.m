clear; clc; close all; format long g;
%MAIN_SIMULATION_HYSTERESIS Run the report-informed 2-D FVEM comparison.

root_dir = fileparts(mfilename('fullpath'));
addpath(genpath(root_dir));
code = current_submission_code();
reference = load_nist_submission(root_dir,code);
param = submission_parameters(code,'reported');
param.output_dir = fullfile(root_dir,'results','simulation');

if param.use_reference_field_schedule
    param.field_schedule_x_mT = ...
        ensure_zero_field_samples(reference.x.Hparallel_mT);
    param.field_schedule_y_mT = ...
        ensure_zero_field_samples(reference.y.Hparallel_mT);
    param.field_direction_x = reference.x.field_direction;
    param.field_direction_y = reference.y.field_direction;
end

result_x = hysteresis_FVEM_2D_solver(param,'x');
result_y = hysteresis_FVEM_2D_solver(param,'y');

plot_hysteresis_results_2D(result_x,result_y,param);
plot_simulation_vs_reference(result_x,result_y,reference,param);
save(fullfile(param.output_dir,[code '_simulation_results.mat']), ...
    'param','result_x','result_y','reference');
write_mumag1_description(param,result_x,result_y);

fprintf('\n%s 2-D FVEM comparison finished.\n',code);
fprintf('Openable FIG files are in:\n  %s\n',param.output_dir);
fprintf('No PNG file is generated.\n');
