function main_reference_remanence_vectors()
%MAIN_REFERENCE_REMANENCE_VECTORS Plot official vector images at remanence.
%
% This can be run independently.  It reads the bundled NIST rx/ry files,
% displays the primary long- and short-axis remanent states, and saves
% directly openable MATLAB FIG files.  No PNG file is generated.

root_dir = fileparts(mfilename('fullpath'));
addpath(genpath(root_dir));
code = current_submission_code();
output_dir = fullfile(root_dir,'results','reference','remanence');

remanence = load_nist_remanence_states(root_dir,code);
plot_nist_remanence_vectors(remanence,output_dir);
plot_nist_colored_remanence(remanence,output_dir);
save(fullfile(output_dir,[code '_remanence_reference_data.mat']), ...
    'remanence');

fprintf('\n%s official NIST Vector Images at Remanence completed.\n',code);
fprintf('Both black-and-white and coloured-angle FIGs were generated.\n');
fprintf('Openable FIG files are in:\n  %s\n',output_dir);
fprintf('No PNG file is generated.\n');
end
