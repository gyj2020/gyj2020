function Hc = zero_crossing_field(H,M)
%ZERO_CROSSING_FIELD Linear interpolation of the first M=0 crossing.

Hc = NaN;
for k = 1:numel(M)-1
    if M(k) == 0
        Hc = H(k);
        return;
    end
    if M(k)*M(k+1) < 0
        Hc = H(k)-M(k)*(H(k+1)-H(k))/(M(k+1)-M(k));
        return;
    end
end
if ~isempty(M) && M(end) == 0
    Hc = H(end);
end
end

