function mbar = volume_average_FVEM_2D(m,control_volume_area)
%VOLUME_AVERAGE_FVEM_2D FVEM control-volume average of magnetization.

w = control_volume_area(:);
mbar = (m*w)/sum(w);
end

