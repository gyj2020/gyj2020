function solver = prepare_exchange_solver(M,K,beta,param)
%PREPARE_EXCHANGE_SOLVER Factor M+beta*K once for all relaxation steps.

Aimp = M+beta*K;
Aimp = 0.5*(Aimp+Aimp.');
method = lower(param.linear_solver);
if strcmp(method,'auto')
    if size(Aimp,1) <= param.direct_threshold
        method = 'chol';
    else
        method = 'pcg';
    end
end

solver = struct('A',Aimp,'type',method,'L',[],'tolerance', ...
    param.pcg_tolerance,'maxit',param.pcg_maxit);

if strcmp(method,'chol')
    [L,p] = chol(Aimp,'lower');
    if p == 0
        solver.L = L;
    else
        warning('Sparse Cholesky failed; switching to PCG.');
        solver.type = 'pcg';
    end
elseif ~strcmp(method,'pcg')
    error('linear_solver must be auto, chol, or pcg.');
end

if strcmp(solver.type,'pcg')
    try
        solver.L = ichol(Aimp,struct('type','ict','droptol',1e-3, ...
            'diagcomp',1e-3));
    catch
        solver.L = [];
    end
end
end

