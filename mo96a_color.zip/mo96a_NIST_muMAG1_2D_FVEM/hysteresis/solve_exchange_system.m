function [x,info] = solve_exchange_system(solver,rhs,x0)
%SOLVE_EXCHANGE_SYSTEM Solve three scalar implicit-exchange systems.

if strcmp(solver.type,'chol')
    x = solver.L'\(solver.L\rhs);
    residual = norm(solver.A*x-rhs,'fro')/max(norm(rhs,'fro'),eps);
    info = struct('converged',isfinite(residual) && residual < 1e-8, ...
        'max_relative_residual',residual,'flags',[0 0 0]);
    return;
end

x = zeros(size(rhs));
flags = zeros(1,size(rhs,2));
relres = zeros(1,size(rhs,2));
for c = 1:size(rhs,2)
    if isempty(solver.L)
        [x(:,c),flags(c),relres(c)] = pcg(solver.A,rhs(:,c), ...
            solver.tolerance,solver.maxit,[],[],x0(:,c));
    else
        [x(:,c),flags(c),relres(c)] = pcg(solver.A,rhs(:,c), ...
            solver.tolerance,solver.maxit,solver.L,solver.L',x0(:,c));
    end
    if flags(c) ~= 0
        % A direct fallback keeps a long hysteresis run from silently
        % propagating a failed Krylov iterate.
        x(:,c) = solver.A\rhs(:,c);
        relres(c) = norm(solver.A*x(:,c)-rhs(:,c))/max(norm(rhs(:,c)),eps);
    end
end
info = struct('converged',all(isfinite(relres)) && max(relres)<1e-8, ...
    'max_relative_residual',max(relres),'flags',flags);
end

