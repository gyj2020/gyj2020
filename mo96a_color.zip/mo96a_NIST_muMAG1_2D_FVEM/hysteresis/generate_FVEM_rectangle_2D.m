function data = generate_FVEM_rectangle_2D(nx,ny,Lx,Ly)
%GENERATE_FVEM_RECTANGLE_2D FVEM primal/dual data on [0,Lx]x[0,Ly].
%
% Coordinates are nondimensional.  The diffusion matrix is assembled from
% fluxes across barycentre-midpoint dual edges.  No physical-boundary flux
% is added, which realizes the homogeneous Neumann exchange condition.

domain = [0 Lx 0 Ly];
[P,T] = generate_uniform_triangular_mesh_2D(nx,ny,domain);
[area,gx,gy] = compute_P1_triangle_geometry(P,T);

N = size(P,2);
E = size(T,2);
[I,J,qcoef1,qcoef2,qcoef3] = ...
    build_barycentric_dual_flux_data(P,T,gx,gy);

Mref = [22 7 7;7 22 7;7 7 22]/108;
MFref = [2 1 1;1 2 1;1 1 2]/12;

Mval = zeros(9,E);
MFval = zeros(9,E);
KEval = zeros(9,E);
r = 0;
for i = 1:3
    for j = 1:3
        r = r+1;
        Mval(r,:) = area*Mref(i,j);
        MFval(r,:) = area*MFref(i,j);
        KEval(r,:) = area.*(gx(i,:).*gx(j,:)+gy(i,:).*gy(j,:));
    end
end

M = sparse(I(:),J(:),Mval(:),N,N);
Mfem = sparse(I(:),J(:),MFval(:),N,N);
Kenergy = sparse(I(:),J(:),KEval(:),N,N);
K = sparse(I(:),J(:),-(qcoef1+qcoef2+qcoef3),N,N);

tol = 100*eps(max([Lx,Ly,1]));
boundary_nodes = find(abs(P(1,:))<tol | abs(P(1,:)-Lx)<tol | ...
                      abs(P(2,:))<tol | abs(P(2,:)-Ly)<tol);

data = struct( ...
    'method','vertex-centred FVEM with barycentre-midpoint dual cells', ...
    'boundary_condition','homogeneous Neumann exchange flux', ...
    'domain',domain,'nx',nx,'ny',ny,'P',P,'T',T,'Pb',P,'Tb',T, ...
    'N',N,'E',E,'area',area,'gx',gx,'gy',gy,'I',I,'J',J, ...
    'M',M,'Mfem',Mfem,'K',K,'Kenergy',Kenergy, ...
    'qcoef1',qcoef1,'qcoef2',qcoef2,'qcoef3',qcoef3, ...
    'control_volume_area',full(sum(M,2)), ...
    'boundary_nodes',boundary_nodes);
end

