function energy = compute_micromagnetic_energy_2D(m,h_ext,ctx,hdemag)
%COMPUTE_MICROMAGNETIC_ENERGY_2D Dimensionless energy per sample area.

if nargin < 4 || isempty(hdemag)
    hdemag = demag_field_fft_2D(m,ctx.demag_grid);
end
w = ctx.mlump;
area_total = sum(w);
mt = m.';

exchange = 0.5*ctx.lex2*sum(sum(mt.*(ctx.K*mt)))/area_total;
demag = -0.5*sum(w.*sum(mt.*hdemag.',2))/area_total;
projection = ctx.easy.'*m;
anisotropy = -0.5*ctx.kappa*sum(w.*projection.'.^2)/area_total;
zeeman = -sum(w.*(mt*h_ext))/area_total;

energy = struct('total',exchange+demag+anisotropy+zeeman, ...
    'exchange',exchange,'demag',demag, ...
    'anisotropy',anisotropy,'zeeman',zeeman);
end

