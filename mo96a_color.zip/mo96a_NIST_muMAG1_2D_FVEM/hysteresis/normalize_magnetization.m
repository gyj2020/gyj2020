function m = normalize_magnetization(m)
%NORMALIZE_MAGNETIZATION Enforce unit length at every node.

lengths = sqrt(sum(m.^2,1));
if any(~isfinite(lengths)) || any(lengths < 100*eps)
    error('Magnetization contains a zero, NaN, or Inf vector.');
end
m = bsxfun(@rdivide,m,lengths);
end

