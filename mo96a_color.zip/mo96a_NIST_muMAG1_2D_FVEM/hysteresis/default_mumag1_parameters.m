function param = default_mumag1_parameters(preset)
%DEFAULT_MUMAG1_PARAMETERS NIST muMAG standard problem #1 settings.

if nargin < 1 || isempty(preset)
    preset = 'normal';
end

param = struct();

% SI constants and material parameters from NIST problem #1.
param.mu0 = 4*pi*1.0e-7;              % H/m
param.A = 1.3e-11;                    % J/m
param.Ms = 8.0e5;                     % A/m
param.Ku = 5.0e2;                     % J/m^3
param.easy_axis = [0;1;0];            % long y-axis

% Sample dimensions.
param.Lx_m = 1.0e-6;                  % short axis
param.Ly_m = 2.0e-6;                  % long axis
param.thickness_m = 20.0e-9;
param.length_scale_m = 1.0e-6;        % nondimensional spatial unit

% NIST field protocol.
param.Hmax_mT = 50.0;
param.cant_deg = 1.0;                 % counterclockwise

% Quasistatic damping relaxation.  relax_step is dimensionless and is not
% a physical time step.  The equilibria satisfy m x h_eff = 0.
param.relax_step = 1.00;
param.max_relax_iter = 1800;
param.min_relax_iter = 10;
param.check_every = 5;
param.tol_torque = 1.0e-4;
param.tol_change = 1.0e-4;
param.verbose_relax = false;

% Thickness-averaged open-film demagnetizing field.  A larger padding
% factor reduces interactions with periodic FFT images at extra cost.
param.demag_pad_factor = 4;

% Linear solve for the implicit exchange update.
param.linear_solver = 'auto';          % auto, chol, or pcg
param.direct_threshold = 30000;
param.pcg_tolerance = 1.0e-10;
param.pcg_maxit = 250;

% Save the converged nodal state at every field only when explicitly set.
param.store_all_states = false;
param.output_dir = fullfile(pwd,'results','hysteresis');

switch lower(preset)
    case 'quick'
        param.nx = 12;
        param.ny = 24;
        param.dH_mT = 25.0;
        param.max_relax_iter = 120;
        param.min_relax_iter = 5;
        param.tol_torque = 2.0e-3;
        param.tol_change = 2.0e-3;
        param.demag_pad_factor = 2;
    case 'normal'
        param.nx = 50;
        param.ny = 100;
        param.dH_mT = 2.0;
    case 'refined'
        param.nx = 100;
        param.ny = 200;
        param.dH_mT = 1.0;
        param.max_relax_iter = 2200;
        param.tol_torque = 5.0e-5;
        param.tol_change = 5.0e-5;
    case {'fine','nist_fine'}
        param.nx = 200;
        param.ny = 400;
        param.dH_mT = 1.0;
        param.max_relax_iter = 3000;
        param.tol_torque = 2.0e-5;
        param.tol_change = 2.0e-5;
        param.demag_pad_factor = 2;
    otherwise
        error('Unknown preset: %s',preset);
end

param.preset = lower(preset);
param.exchange_length_m = sqrt(2*param.A/(param.mu0*param.Ms^2));
param.exchange_coefficient = ...
    (param.exchange_length_m/param.length_scale_m)^2;
param.anisotropy_coefficient = 2*param.Ku/(param.mu0*param.Ms^2);
end
