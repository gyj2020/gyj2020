function write_remanent_state_2D(filename,P,param,m)
%WRITE_REMANENT_STATE_2D NIST six-column remanent-state ASCII format.

fid = fopen(filename,'w');
if fid < 0
    error('Cannot open %s for writing.',filename);
end
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
[~,name,ext] = fileparts(filename);
fprintf(fid,'# File: %s%s\n',name,ext);
fprintf(fid,'# x(microns) y(microns) z(microns) m_x m_y m_z\n');

scale_um = param.length_scale_m*1e6;
z_um = 0.5*param.thickness_m*1e6;
for k = 1:size(P,2)
    fprintf(fid,'%16.9e %16.9e %16.9e %+16.9e %+16.9e %+16.9e\n', ...
        P(1,k)*scale_um,P(2,k)*scale_um,z_um, ...
        m(1,k),m(2,k),m(3,k));
end
end

