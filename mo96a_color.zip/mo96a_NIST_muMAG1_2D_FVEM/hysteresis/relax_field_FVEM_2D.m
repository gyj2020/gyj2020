function [m,info] = relax_field_FVEM_2D(m,h_ext,ctx)
%RELAX_FIELD_FVEM_2D Damping-only LL relaxation at fixed applied field.
%
% The tangential energy descent direction is
%   p = h_eff-(m.h_eff)m = -m x (m x h_eff).
% It is smoothed with the FVEM exchange preconditioner
%   (D+eta*lex^2*K)v=D*p,
% reprojected onto the nodal tangent spaces, and followed by nodal
% normalization of m+eta*v.  D contains the dual-control-volume areas.
% Its fixed points satisfy m x h_eff=0.

param = ctx.param;
eta = param.relax_step;
D = ctx.D;

m = enforce_model_dimension(normalize_magnetization(m),param);
last_change = inf;
last_torque = inf;
energy_sample = [];
energy_iter = [];
linear_failures = 0;
converged = false;

for iter = 1:param.max_relax_iter
    heff = effective_field_FVEM_2D(m,h_ext,ctx);
    descent = heff-bsxfun(@times,m,sum(m.*heff,1));
    rhs = D*descent.';
    [v,linfo] = solve_exchange_system(ctx.exchange_solver,rhs,descent.');
    if ~linfo.converged
        linear_failures = linear_failures+1;
    end
    v = v.';
    v = v-bsxfun(@times,m,sum(m.*v,1));
    mnew = enforce_model_dimension(normalize_magnetization(m+eta*v),param);
    last_change = max(sqrt(sum((mnew-m).^2,1)));
    m = mnew;

    do_check = iter == 1 || iter == param.max_relax_iter || ...
        mod(iter,param.check_every) == 0;
    if do_check
        [heff,fields] = effective_field_FVEM_2D(m,h_ext,ctx);
        torque = column_cross(m,heff);
        last_torque = max(sqrt(sum(torque.^2,1)));
        en = compute_micromagnetic_energy_2D(m,h_ext,ctx,fields.hdemag);
        energy_sample(:,end+1) = [en.total;en.exchange;en.demag; ...
            en.anisotropy;en.zeeman]; %#ok<AGROW>
        energy_iter(end+1) = iter; %#ok<AGROW>

        if param.verbose_relax
            fprintf('    relax %4d: torque=%.3e, change=%.3e, E=%.9e\n', ...
                iter,last_torque,last_change,en.total);
        end
        if iter >= param.min_relax_iter && ...
                last_torque <= param.tol_torque && ...
                last_change <= param.tol_change
            converged = true;
            break;
        end
    end
end

[~,fields] = effective_field_FVEM_2D(m,h_ext,ctx);
en = compute_micromagnetic_energy_2D(m,h_ext,ctx,fields.hdemag);
info = struct('iterations',iter,'converged',converged, ...
    'torque',last_torque,'change',last_change,'energy',en, ...
    'energy_history',energy_sample,'energy_iterations',energy_iter, ...
    'linear_failures',linear_failures);
end

function m = enforce_model_dimension(m,param)
if isfield(param,'planar_magnetization') && param.planar_magnetization
    m(3,:) = 0;
    m = normalize_magnetization(m);
end
end
