function plot_hysteresis_results_2D(result_x,result_y,param)
%PLOT_HYSTERESIS_RESULTS_2D Loop, components, energy, and convergence plots.

out = param.output_dir;
if ~exist(out,'dir')
    mkdir(out);
end

prefix = 'mumag1';
display_name = 'NIST muMAG problem 1';
if isfield(param,'submission_code') && ~isempty(param.submission_code)
    prefix = lower(param.submission_code);
    display_name = ['NIST submission ' prefix ' (2-D FVEM simulation)'];
end

fig = figure('Color','w','Visible','on');
hlimit = max([param.Hmax_mT,max(abs(result_x.Hscalar_mT)), ...
    max(abs(result_y.Hscalar_mT))]);
plot(result_x.Hscalar_mT,result_x.m_parallel,'-o', ...
    'MarkerSize',3,'LineWidth',1.2); hold on;
plot(result_y.Hscalar_mT,result_y.m_parallel,'-s', ...
    'MarkerSize',3,'LineWidth',1.2);
plot([-hlimit hlimit],[0 0],':', ...
    'Color',[0.45 0.45 0.45]);
plot([0 0],[-1.1 1.1],':','Color',[0.45 0.45 0.45]);
xlabel('\mu_0H (mT)');
ylabel('M_{parallel}/M_s');
legend('near short x-axis','near long y-axis','Location','best');
title([display_name ': both field axes'],'Interpreter','none');
xlim([-hlimit hlimit]);
ylim([-1.1 1.1]); grid on; box on;
save_openable_fig(fig,fullfile(out,[prefix '_simulation_hysteresis_both_axes.fig']));

plot_components(result_x,fullfile(out,[prefix '_simulation_short_axis_components.fig']), ...
    'Field near short x-axis');
plot_components(result_y,fullfile(out,[prefix '_simulation_long_axis_components.fig']), ...
    'Field near long y-axis');
plot_energy(result_x,fullfile(out,[prefix '_simulation_short_axis_energy.fig']), ...
    'Energy, field near short x-axis');
plot_energy(result_y,fullfile(out,[prefix '_simulation_long_axis_energy.fig']), ...
    'Energy, field near long y-axis');
end

function plot_components(result,filename,plot_title)
fig = figure('Color','w','Visible','on');
plot(result.Hscalar_mT,result.mavg(1,:),'-','LineWidth',1.25); hold on;
plot(result.Hscalar_mT,result.mavg(2,:),'--','LineWidth',1.25);
plot(result.Hscalar_mT,result.mavg(3,:),':','LineWidth',1.25);
xlabel('\mu_0H (mT)'); ylabel('M_i/M_s');
legend('m_x','m_y','m_z','Location','best');
title(plot_title); grid on; box on;
save_openable_fig(fig,filename);
end

function plot_energy(result,filename,plot_title)
fig = figure('Color','w','Visible','on');
plot(result.Hscalar_mT,result.energy.','LineWidth',1.05);
xlabel('\mu_0H (mT)'); ylabel('reduced energy density');
legend(result.energy_names,'Location','best');
title(plot_title); grid on; box on;
save_openable_fig(fig,filename);
end

function save_openable_fig(fig,filename)
% Save with Visible='on'.  MATLAB stores this property inside a FIG file;
% keeping it on ensures that double-click/openfig displays the graphics.
set(fig,'Visible','on');
drawnow;
savefig(fig,filename);
end
