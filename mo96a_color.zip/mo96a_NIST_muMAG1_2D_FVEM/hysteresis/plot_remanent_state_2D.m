function plot_remanent_state_2D(filename,data,param,m,plot_title)
%PLOT_REMANENT_STATE_2D Quiver/colour view of a remanent state.

nxn = param.nx+1;
nyn = param.ny+1;
mx = reshape(m(1,:),nyn,nxn);
my = reshape(m(2,:),nyn,nxn);
theta = atan2(my,mx);
x = linspace(0,param.Lx_m*1e6,nxn);
y = linspace(0,param.Ly_m*1e6,nyn);
[X,Y] = meshgrid(x,y);

stride_x = max(1,ceil(nxn/26));
stride_y = max(1,ceil(nyn/42));
ix = 1:stride_x:nxn;
iy = 1:stride_y:nyn;

fig = figure('Color','w','Visible','on');
imagesc(x,y,theta);
set(gca,'YDir','normal');
axis image;
colormap(hsv);
caxis([-pi pi]);
colorbar;
hold on;
quiver(X(iy,ix),Y(iy,ix),mx(iy,ix),my(iy,ix),0.55, ...
    'k','LineWidth',0.8);
xlabel('x (\mum)');
ylabel('y (\mum)');
title(plot_title,'Interpreter','none');
box on;
set(fig,'Visible','on');
drawnow;
savefig(fig,filename);
end
