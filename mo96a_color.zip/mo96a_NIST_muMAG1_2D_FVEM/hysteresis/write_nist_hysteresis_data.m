function write_nist_hysteresis_data(filename,Hscalar_mT,eH,mavg)
%WRITE_NIST_HYSTERESIS_DATA NIST seven-column ASCII loop format.

fid = fopen(filename,'w');
if fid < 0
    error('Cannot open %s for writing.',filename);
end
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>

[~,name,ext] = fileparts(filename);
fprintf(fid,'# File: %s%s\n',name,ext);
fprintf(fid,'# Units: mT\n');
fprintf(fid,'# Step H_x H_y H_z m_x m_y m_z\n');
for k = 1:numel(Hscalar_mT)
    Hvec = Hscalar_mT(k)*eH;
    fprintf(fid,'%5d %+16.9e %+16.9e %+16.9e %+16.9e %+16.9e %+16.9e\n', ...
        k,Hvec(1),Hvec(2),Hvec(3), ...
        mavg(1,k),mavg(2,k),mavg(3,k));
end
end

