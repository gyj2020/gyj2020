function result = hysteresis_FVEM_2D_solver(param,axis_name)
%HYSTERESIS_FVEM_2D_SOLVER Complete quasistatic NIST problem #1 loop.
%
% The exchange field uses the vertex-centred FVEM diffusion operator.
% At every applied-field value, a damping-only Landau--Lifshitz relaxation
% follows the current metastable branch until max|m x h_eff| is small.

if nargin < 2
    axis_name = 'y';
end
if ~exist(param.output_dir,'dir')
    mkdir(param.output_dir);
end

Lx = param.Lx_m/param.length_scale_m;
Ly = param.Ly_m/param.length_scale_m;
data = generate_FVEM_rectangle_2D(param.nx,param.ny,Lx,Ly);
M = assemble_matrix_M_FVEM_2D(data);
K = assemble_matrix_FVEM_2D(data);
mlump = full(sum(M,2));
D = spdiags(mlump,0,data.N,data.N);

lex2 = (sqrt(2*param.A/(param.mu0*param.Ms^2))/ ...
    param.length_scale_m)^2;
kappa = 2*param.Ku/(param.mu0*param.Ms^2);
easy = param.easy_axis(:)/norm(param.easy_axis);

exchange_solver = prepare_exchange_solver( ...
    D,K,param.relax_step*lex2,param);
demag_grid = prepare_demag_fft_2D(param);

ctx = struct('param',param,'data',data,'M',M,'D',D,'K',K, ...
    'mlump',mlump,'lex2',lex2,'kappa',kappa,'easy',easy, ...
    'exchange_solver',exchange_solver,'demag_grid',demag_grid);

angle = param.cant_deg*pi/180;
prefix = 'mumag1';
if isfield(param,'submission_code') && ~isempty(param.submission_code)
    prefix = lower(param.submission_code);
end
switch lower(axis_name)
    case 'x'
        if isfield(param,'field_direction_x') && ...
                ~isempty(param.field_direction_x)
            eH = param.field_direction_x(:);
            eH = eH/norm(eH);
        else
            eH = [cos(angle);sin(angle);0];
        end
        tag = 'short_x';
        loop_file = fullfile(param.output_dir,[prefix '_sim_hyx.dat']);
        rem_prefix = [prefix '_sim_rx'];
        schedule_name = 'field_schedule_x_mT';
    case 'y'
        % Counterclockwise from +y means an absolute angle of 90+angle.
        if isfield(param,'field_direction_y') && ...
                ~isempty(param.field_direction_y)
            eH = param.field_direction_y(:);
            eH = eH/norm(eH);
        else
            eH = [-sin(angle);cos(angle);0];
        end
        tag = 'long_y';
        loop_file = fullfile(param.output_dir,[prefix '_sim_hyy.dat']);
        rem_prefix = [prefix '_sim_ry'];
        schedule_name = 'field_schedule_y_mT';
    otherwise
        error('axis_name must be ''x'' or ''y''.');
end

if isfield(param,schedule_name) && ~isempty(param.(schedule_name))
    Hscalar_mT = param.(schedule_name)(:).';
    if any(~isfinite(Hscalar_mT)) || numel(Hscalar_mT) < 2
        error('%s must contain at least two finite field values.',schedule_name);
    end
    [~,n_desc] = min(Hscalar_mT);
    branch = ones(size(Hscalar_mT));
    branch((n_desc+1):end) = 2;
else
    [Hscalar_mT,branch,n_desc] = complete_field_sweep( ...
        param.Hmax_mT,param.dH_mT);
end
n_field = numel(Hscalar_mT);

% Use the initialization reported for the selected historical submission.
m = make_initial_state(eH,data.N,param);

mavg = zeros(3,n_field);
mparallel = zeros(1,n_field);
iterations = zeros(1,n_field);
torque_final = zeros(1,n_field);
change_final = zeros(1,n_field);
converged = false(1,n_field);
energy = zeros(5,n_field);
if param.store_all_states
    states = zeros(3,data.N,n_field);
else
    states = [];
end
remanence_desc = [];
remanence_asc = [];

fprintf('\n============================================================\n');
fprintf('NIST muMAG problem #1: field near %s axis\n',axis_name);
fprintf('FVEM mesh: %d x %d rectangles, %d nodes\n', ...
    param.nx,param.ny,data.N);
fprintf('cell: %.5g x %.5g nm; exchange length: %.5g nm\n', ...
    param.Lx_m/param.nx*1e9,param.Ly_m/param.ny*1e9, ...
    sqrt(2*param.A/(param.mu0*param.Ms^2))*1e9);
fprintf('field states: %d; FFT grid: %d x %d\n', ...
    n_field,demag_grid.px,demag_grid.py);
fprintf('============================================================\n');

timer_id = tic;
for ih = 1:n_field
    Bscalar_T = Hscalar_mT(ih)*1.0e-3;
    h_ext = (Bscalar_T/(param.mu0*param.Ms))*eH;

    [m,info] = relax_field_FVEM_2D(m,h_ext,ctx);
    mbar = volume_average_FVEM_2D(m,mlump);

    mavg(:,ih) = mbar;
    mparallel(ih) = dot(mbar,eH);
    iterations(ih) = info.iterations;
    torque_final(ih) = info.torque;
    change_final(ih) = info.change;
    converged(ih) = info.converged;
    energy(:,ih) = [info.energy.total;info.energy.exchange; ...
        info.energy.demag;info.energy.anisotropy;info.energy.zeeman];

    if param.store_all_states
        states(:,:,ih) = m;
    end
    if abs(Hscalar_mT(ih)) <= 10*eps(param.Hmax_mT)
        if branch(ih) == 1
            remanence_desc = m;
        else
            remanence_asc = m;
        end
    end

    mark = '';
    if ~info.converged
        mark = '  [max iterations]';
    end
    fprintf(['%s %3d/%3d: mu0H=%+7.2f mT, Mpar=%+.7f, ' ...
        'iter=%4d, torque=%.3e%s\n'],tag,ih,n_field, ...
        Hscalar_mT(ih),mparallel(ih),info.iterations,info.torque,mark);
end
elapsed_seconds = toc(timer_id);

write_nist_hysteresis_data(loop_file,Hscalar_mT,eH,mavg);
if ~isempty(remanence_desc)
    write_remanent_state_2D(fullfile(param.output_dir, ...
        [rem_prefix '1.dat']),data.P,param,remanence_desc);
    plot_remanent_state_2D(fullfile(param.output_dir, ...
        [rem_prefix '1.fig']),data,param,remanence_desc, ...
        [tag ', descending remanence']);
end
if ~isempty(remanence_asc)
    write_remanent_state_2D(fullfile(param.output_dir, ...
        [rem_prefix '2.dat']),data.P,param,remanence_asc);
    plot_remanent_state_2D(fullfile(param.output_dir, ...
        [rem_prefix '2.fig']),data,param,remanence_asc, ...
        [tag ', ascending remanence']);
end

Hdesc = Hscalar_mT(1:n_desc);
Mdesc = mparallel(1:n_desc);
Hasc = Hscalar_mT(n_desc+1:end);
Masc = mparallel(n_desc+1:end);

result = struct();
result.axis_name = lower(axis_name);
result.field_direction = eH;
result.Hscalar_mT = Hscalar_mT;
result.Hvector_mT = eH*Hscalar_mT;
result.branch = branch;
result.mavg = mavg;
result.m_parallel = mparallel;
result.iterations = iterations;
result.torque_final = torque_final;
result.change_final = change_final;
result.converged = converged;
result.energy_names = {'total','exchange','demag','anisotropy','zeeman'};
result.energy = energy;
result.Hc_desc_mT = zero_crossing_field(Hdesc,Mdesc);
result.Hc_asc_mT = zero_crossing_field(Hasc,Masc);
result.Mr_desc = magnetization_at_zero_field(Hdesc,Mdesc);
result.Mr_asc = magnetization_at_zero_field(Hasc,Masc);
result.remanence_desc = remanence_desc;
result.remanence_asc = remanence_asc;
result.final_state = m;
result.states = states;
result.P = data.P;
result.T = data.T;
result.elapsed_seconds = elapsed_seconds;
result.nonconverged_fields = find(~converged);
result.method = ['2-D thickness-averaged demag FFT plus ' ...
    'vertex-centred FVEM exchange relaxation'];
end

function m = make_initial_state(eH,N,param)
initial_state = 'uniform';
if isfield(param,'initial_state') && ~isempty(param.initial_state)
    initial_state = lower(param.initial_state);
end

switch initial_state
    case {'uniform','uniform positive saturation'}
        m = repmat(eH,1,N);
    case 'random'
        seed = 9701;
        if isfield(param,'random_seed') && ~isempty(param.random_seed)
            seed = param.random_seed;
        end
        rng(seed,'twister');
        m = 2*rand(3,N)-1;
    otherwise
        error('Unsupported initial_state: %s',initial_state);
end

if isfield(param,'planar_magnetization') && param.planar_magnetization
    m(3,:) = 0;
end
m = normalize_magnetization(m);
end

function [H,branch,n_desc] = complete_field_sweep(Hmax,dH)
if Hmax <= 0 || dH <= 0
    error('Hmax_mT and dH_mT must be positive.');
end
positive = Hmax:-dH:0;
if positive(end) > 10*eps(Hmax)
    positive = [positive 0]; %#ok<AGROW>
else
    positive(end) = 0;
end
negative = -dH:-dH:-Hmax;
if isempty(negative) || negative(end) > -Hmax+10*eps(Hmax)
    negative = [negative -Hmax]; %#ok<AGROW>
else
    negative(end) = -Hmax;
end
descending = [positive negative];
ascending = descending(end-1:-1:1);
H = [descending ascending];
n_desc = numel(descending);
branch = [ones(1,n_desc),2*ones(1,numel(ascending))];
end
