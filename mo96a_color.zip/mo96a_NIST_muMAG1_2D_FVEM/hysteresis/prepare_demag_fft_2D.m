function grid = prepare_demag_fft_2D(param)
%PREPARE_DEMAG_FFT_2D Thickness-averaged thin-film demag tensor.
%
% For in-plane wave vector k, the thickness-averaged tensor is
%   Nzz = (1-exp(-|k|t))/(|k|t),
%   Nij = (ki*kj/|k|^2)*(1-Nzz), i,j=x,y.
% Magnetization is zero-padded outside the rectangular sample before the
% FFT, giving an open-boundary approximation rather than a sample-periodic
% calculation.

nxn = param.nx+1;
nyn = param.ny+1;
Lx = param.Lx_m/param.length_scale_m;
Ly = param.Ly_m/param.length_scale_m;
t = param.thickness_m/param.length_scale_m;
dx = Lx/param.nx;
dy = Ly/param.ny;

pad = max(2,round(param.demag_pad_factor));
px = 2^nextpow2(pad*nxn);
py = 2^nextpow2(pad*nyn);

kx = fft_wavenumbers(px,dx);
ky = fft_wavenumbers(py,dy);
[KX,KY] = meshgrid(kx,ky);
Kabs = sqrt(KX.^2+KY.^2);

Nzz = ones(py,px);
nz = Kabs > 0;
z = Kabs(nz)*t;
% expm1 avoids cancellation for small z.
Nzz(nz) = -expm1(-z)./z;
Ginplane = 1-Nzz;

Nxx = zeros(py,px);
Nyy = zeros(py,px);
Nxy = zeros(py,px);
K2 = Kabs(nz).^2;
Nxx(nz) = Ginplane(nz).*KX(nz).^2./K2;
Nyy(nz) = Ginplane(nz).*KY(nz).^2./K2;
Nxy(nz) = Ginplane(nz).*KX(nz).*KY(nz)./K2;

row0 = floor((py-nyn)/2)+1;
col0 = floor((px-nxn)/2)+1;

grid = struct('nx_nodes',nxn,'ny_nodes',nyn,'px',px,'py',py, ...
    'rows',row0:(row0+nyn-1),'cols',col0:(col0+nxn-1), ...
    'dx',dx,'dy',dy,'thickness',t, ...
    'Nxx',Nxx,'Nxy',Nxy,'Nyy',Nyy,'Nzz',Nzz);
end

function k = fft_wavenumbers(n,d)
if mod(n,2) == 0
    index = [0:(n/2-1), -n/2:-1];
else
    index = [0:((n-1)/2), -(n-1)/2:-1];
end
k = (2*pi/(n*d))*index;
end

