function Mr = magnetization_at_zero_field(H,M)
%MAGNETIZATION_AT_ZERO_FIELD M at H=0, with linear interpolation fallback.

[v,k] = min(abs(H));
if v <= 10*eps(max(abs(H)))
    Mr = M(k);
    return;
end
Mr = interp1(H,M,0,'linear',NaN);
end

