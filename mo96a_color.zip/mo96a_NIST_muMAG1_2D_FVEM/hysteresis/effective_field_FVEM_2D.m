function [heff,fields] = effective_field_FVEM_2D(m,h_ext,ctx)
%EFFECTIVE_FIELD_FVEM_2D Reduced field h_eff=H_eff/Ms.

Km = ctx.K*m.';
hex = (-ctx.lex2*bsxfun(@rdivide,Km,ctx.mlump)).';
hdemag = demag_field_fft_2D(m,ctx.demag_grid);
hani = ctx.kappa*(ctx.easy*(ctx.easy.'*m));
hext = repmat(h_ext,1,ctx.data.N);
heff = hex+hdemag+hani+hext;

fields = struct('exchange',hex,'hdemag',hdemag, ...
    'anisotropy',hani,'applied',hext);
end

