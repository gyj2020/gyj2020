function hdemag = demag_field_fft_2D(m,grid)
%DEMAG_FIELD_FFT_2D Reduced demagnetizing field H_demag/Ms.

if size(m,1) ~= 3 || size(m,2) ~= grid.nx_nodes*grid.ny_nodes
    error('m must be 3-by-(nx+1)(ny+1), using FVEM node ordering.');
end

mx = reshape(m(1,:),grid.ny_nodes,grid.nx_nodes);
my = reshape(m(2,:),grid.ny_nodes,grid.nx_nodes);
mz = reshape(m(3,:),grid.ny_nodes,grid.nx_nodes);

Mx = zeros(grid.py,grid.px);
My = zeros(grid.py,grid.px);
Mz = zeros(grid.py,grid.px);
Mx(grid.rows,grid.cols) = mx;
My(grid.rows,grid.cols) = my;
Mz(grid.rows,grid.cols) = mz;

FMx = fft2(Mx);
FMy = fft2(My);
FMz = fft2(Mz);

FHx = -(grid.Nxx.*FMx + grid.Nxy.*FMy);
FHy = -(grid.Nxy.*FMx + grid.Nyy.*FMy);
FHz = -grid.Nzz.*FMz;

hx = real(ifft2(FHx));
hy = real(ifft2(FHy));
hz = real(ifft2(FHz));
hx = hx(grid.rows,grid.cols);
hy = hy(grid.rows,grid.cols);
hz = hz(grid.rows,grid.cols);

hdemag = [reshape(hx,1,[]);reshape(hy,1,[]);reshape(hz,1,[])];
end

