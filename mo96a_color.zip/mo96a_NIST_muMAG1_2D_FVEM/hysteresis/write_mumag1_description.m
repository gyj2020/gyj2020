function write_mumag1_description(param,result_x,result_y)
%WRITE_MUMAG1_DESCRIPTION Reproducibility record for the simulation.

prefix = 'mumag1';
if isfield(param,'submission_code') && ~isempty(param.submission_code)
    prefix = lower(param.submission_code);
end
filename = fullfile(param.output_dir,[prefix '_simulation_description.txt']);
fid = fopen(filename,'w');
if fid < 0
    error('Cannot open %s for writing.',filename);
end
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'NIST muMAG standard problem #1 -- 2-D MATLAB/FVEM run\n');
fprintf(fid,'Historical comparison submission: %s\n',prefix);
fprintf(fid,'Units: SI; loop field files use mT\n');
fprintf(fid,'Magnetization dimensionality: 3 components, thickness-uniform\n');
fprintf(fid,'Grid dimensionality: 2-D triangular primal grid\n');
fprintf(fid,'Sample: %.9g x %.9g x %.9g m\n', ...
    param.Lx_m,param.Ly_m,param.thickness_m);
fprintf(fid,'Material: A=%.9g J/m, Ms=%.9g A/m, Ku=%.9g J/m^3\n', ...
    param.A,param.Ms,param.Ku);
fprintf(fid,'Easy axis: [%g %g %g]\n',param.easy_axis);
fprintf(fid,'Mesh rectangles: %d x %d; triangles: %d; nodes: %d\n', ...
    param.nx,param.ny,2*param.nx*param.ny,(param.nx+1)*(param.ny+1));
fprintf(fid,'Nominal cell: %.9g x %.9g x %.9g nm\n', ...
    param.Lx_m/param.nx*1e9,param.Ly_m/param.ny*1e9, ...
    param.thickness_m*1e9);
fprintf(fid,'Exchange length: %.9g nm\n',param.exchange_length_m*1e9);
if isfield(param,'initial_state')
    fprintf(fid,'Rerun initial state: %s\n',param.initial_state);
end
if isfield(param,'reported_initial_state')
    fprintf(fid,'Historical reported initial state: %s\n', ...
        param.reported_initial_state);
end
if isfield(param,'field_schedule_x_mT') || ...
        isfield(param,'field_schedule_y_mT')
    fprintf(fid,['Field sweep: bundled historical field sequences used ' ...
        'separately for x/y loops\n']);
else
    fprintf(fid,['Field sweep: +%.9g to -%.9g to +%.9g mT, ' ...
        'requested step %.9g mT\n'],param.Hmax_mT,param.Hmax_mT, ...
        param.Hmax_mT,param.dH_mT);
end
fprintf(fid,'Field states x/y: %d / %d\n', ...
    numel(result_x.Hscalar_mT),numel(result_y.Hscalar_mT));
fprintf(fid,'Canting angle: %.9g degrees counterclockwise\n',param.cant_deg);
fprintf(fid,['Exchange: vertex-centred FVEM dual-control-volume flux, ' ...
    'homogeneous Neumann boundary\n']);
fprintf(fid,['Demag: thickness-averaged Fourier thin-film tensor with ' ...
    'zero padding factor %d\n'],param.demag_pad_factor);
if isfield(param,'reported_demag_method')
    fprintf(fid,'Historical reported demag method: %s\n', ...
        param.reported_demag_method);
end
if isfield(param,'reported_solver')
    fprintf(fid,'Historical reported solver: %s\n',param.reported_solver);
end
fprintf(fid,['Solver: semi-implicit normalized damping-only ' ...
    'Landau--Lifshitz relaxation\n']);
fprintf(fid,'Stopping: max|m x h_eff| <= %.9g and max|delta m| <= %.9g\n', ...
    param.tol_torque,param.tol_change);
fprintf(fid,'Short-axis Hc descending/ascending (mT): %.9g / %.9g\n', ...
    result_x.Hc_desc_mT,result_x.Hc_asc_mT);
fprintf(fid,'Long-axis Hc descending/ascending (mT): %.9g / %.9g\n', ...
    result_y.Hc_desc_mT,result_y.Hc_asc_mT);
fprintf(fid,'Short-axis Mr descending/ascending: %.9g / %.9g\n', ...
    result_x.Mr_desc,result_x.Mr_asc);
fprintf(fid,'Long-axis Mr descending/ascending: %.9g / %.9g\n', ...
    result_y.Mr_desc,result_y.Mr_asc);
fprintf(fid,'Nonconverged field states x/y: %d / %d\n', ...
    numel(result_x.nonconverged_fields),numel(result_y.nonconverged_fields));
fprintf(fid,'Runtime x/y (s): %.9g / %.9g\n', ...
    result_x.elapsed_seconds,result_y.elapsed_seconds);
fprintf(fid,['Qualification: this is a thickness-averaged 2-D model. ' ...
    'A mesh/padding study and comparison with a full 3-D code such as ' ...
    'OOMMF are required before claiming benchmark-grade agreement.\n']);
if isfield(param,'reproduction_scope')
    fprintf(fid,'Reproduction scope: %s\n',param.reproduction_scope);
end
end
