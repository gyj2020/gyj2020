打开方式：
1. 将本压缩包完整解压。
2. 在 MATLAB 中将当前文件夹切换到本目录。
3. 在命令窗口运行 rebuild_matlab_figures
4. 原生 MATLAB FIG 文件将生成在 matlab_figures 文件夹。

quick_hysteresis_results.mat 已转换为 MATLAB v7 MAT 格式。
.ofig 是 Octave 原始图形，只供 Octave 使用，不可用 MATLAB 直接打开。
绘图脚本使用已有计算结果，不需要重新运行模拟。
此处未安装 MATLAB，因此尚未在 MATLAB 中验证重建脚本。
粗网格计算中部分磁场点达到迭代上限，不适合用作高精度物理结论。
