function rebuild_matlab_figures()
% Run this function in MATLAB to regenerate native MATLAB FIG files.
root = fileparts(mfilename('fullpath'));
addpath(fullfile(root,'plotting'));
s = load(fullfile(root,'quick_hysteresis_results.mat'));
param = s.param;
param.output_dir = fullfile(root,'matlab_figures');
if ~exist(param.output_dir,'dir'), mkdir(param.output_dir); end
plot_hysteresis_results_2D(s.result_x,s.result_y,param);
results = {s.result_x,s.result_y};
axes_names = {'x','y'};
for k = 1:2
    r = results{k};
    states = {r.remanence_desc,r.remanence_asc};
    for j = 1:2
        m = states{j};
        if isempty(m), continue; end
        filename = fullfile(param.output_dir,sprintf('mo96a_sim_r%s%d.fig',axes_names{k},j));
        plot_remanent_state_2D(filename,[],param,m,sprintf('Remanence %s %d',axes_names{k},j));
    end
end
fprintf('MATLAB FIG files saved in: %s\n',param.output_dir);
end
